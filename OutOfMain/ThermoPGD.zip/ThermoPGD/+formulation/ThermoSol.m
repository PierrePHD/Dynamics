classdef FEMSol < handle
%FEMSol A class to represente any kind of FEM solution discretized on a
%high diemensional space
    properties
        meshes; % The meshes support of the solution
        kind_of_rep; % 
        data; % A structure to hold all the data
    end
    
    methods
        function obj = FEMSol(meshes,representation)
            
            % Check inputs
            if ~iscell(meshes) || ~iscell(representation) || length(meshes) ~= length(representation) || ...
               all(cellfun(@(s) ~isa(s,'mesh.Mesh'),meshes)) || ...
               all(cellfun(@(s) strcmpi(s,'Nodes') || strcmpi(s,'Elems'),representation))
                error('ThermoPGD:ThermoSol:BadInput','The constructor inputs are a cell array of mesh object and a cell of string values in [''Nodes'',''Elems''].');
            end
            
            % save it
            obj.meshes = meshes;
            obj.kind_of_rep = representation;
        end
    end
    
end