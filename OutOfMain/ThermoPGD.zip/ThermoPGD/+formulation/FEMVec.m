function K = FEMVec(mesh,odr,fct_handle,varargin)
%FEMVec Compute the Finite Element vector
%
%   FEMVec compute the Finite Element vector associated to the computation
%   of int_x f(x) * d^(ord)v/dx dx where f is a function only of x given as
%   a fct_handle.
%
%   see FEMMat.
%
%   Copyright 2014 Pierre-Eric Allier

    % Input Check
    if ~isa(mesh,'mesh.Mesh') || odr < 0 || odr > 1 || ~isa(fct_handle,'function_handle')
    	error('ThermoPGD:FEMVec:BadInput','Bad input, check the doc.');
    end

    is_elem = false; % Not elementary matrix
    for i=1:length(varargin)
        switch varargin{i}
            case 'elementary'
                is_elem = true;
            otherwise
                warning('ThermoPGD:FEMVec','Unknown input argument');
        end
    end
    
    % Get the specific shapes and gauss point for the element
    switch mesh.elem_type
        case 'NODE'
            shapes{1} = @(a,x) 1;
            shapes{2} = @(a,x) 0;
            jac = @(a,x) 1;
            
            xg = 1;
            wg = 1;
        case 'TRESS'
            shapes{1} = @(a,x) [(1-a) (1+a)]/2;
            DN = @(a,x) [-ones(size(a)) ones(size(a))]/2;
            jac = @(a,x) DN(a)*x;
            shapes{2} = @(a,x) cell2mat(cellfun(@(ai) jac(ai,x)\DN(ai),num2cell(a,2),'UniformOutput',false));
            
            xg = [0.774596669241483 0.0 -0.774596669241483]';
            wg = [0.555555555555556 0.888888888888889 0.555555555555556];
        case 'TRI'
            shapes{1} = @(a,x) [a(:,1) a(:,2) 1-a(:,1)-a(:,2)];
            DN = @(a) reshape([ones(size(a(:,1))) zeros(size(a(:,1))) -ones(size(a(:,1))) ...
                               zeros(size(a(:,1))) ones(size(a(:,1))) -ones(size(a(:,1)))]',3,[])';
            jac = @(a,x) DN(a)*x;
            shapes{2} = @(a,x) cell2mat(cellfun(@(ai) jac(ai,x)\DN(ai),num2cell(a,2),'UniformOutput',false));
            
            xg = [0.166666666666667 0.166666666666667;0.166666666666667 0.666666666666667;0.666666666666667 0.166666666666667];
            wg = [0.166666666666667 0.166666666666667 0.166666666666667];
        case 'QUAD'
            shapes{1} = @(a,x) [(a(:,1)-1)*(a(:,2)-1) (a(:,1)+1)*(a(:,2)+1) ...
                                (a(:,1)+1)*(a(:,2)-1) (a(:,1)-1)*(a(:,2)+1)]/4;
            DN = @(a) reshape([(a(:,2)-1) (a(:,2)+1) (a(:,2)-1) (a(:,2)+1) ...
                               (a(:,1)-1) (a(:,1)+1) (a(:,1)+1) (a(:,1)-1)]',4,[])';
            jac = @(a,x) DN(a)*x;
            shapes{2} = @(a,x) cell2mat(cellfun(@(ai) jac(ai,x)\DN(ai),num2cell(a,2),'UniformOutput',false));
            
            xg = [-0.57735026918962576450 -0.57735026918962576450; ...
                   0.57735026918962576450 -0.57735026918962576450; ...
                  -0.57735026918962576450  0.57735026918962576450; ...
                   0.57735026918962576450  0.57735026918962576450];
            wg = [1 1 1 1];
    end
    
    if is_elem
        K = cell(mesh.nbElems(),1);
    else
        K = sparse(mesh.nbNodes(),1); % We are in thermic
    end
    
    % Assembling
    for i=1:mesh.nbElems()
        index = mesh.elems(i,:); % Since we are in thermic, the id of nodes == the index in the matrix
        
        x = mesh.nodes(index,:); % Global coordinate of the node
        
        % In case of TRESS element in 2D, we need to switch to the
        % curvilligne abscisse
        if strcmp(mesh.elem_type, 'TRESS')
            s = sqrt(sum(x.^2,2));
        else
            s = x;
        end
        
        M1 = cell2mat(cellfun(@(a) fct_handle(shapes{1}(a,s)*x),num2cell(xg,2),'UniformOutput',false));% Evaluation of the function
        M2 = shapes{odr+1}(xg,s);
        
        D = cellfun(@(w,a,g) w*det(jac(a,s)),num2cell(wg(:)),num2cell(xg,2),'UniformOutput',false);

        if size(M1,1) > size(M2,1) && strcmp(mesh.elem_type,'TRESS') % We imply to use the normal of the fonction 
            N = zeros(size(M2,1),size(M1,1));
            for j=1:size(M2,1)
                N(j,j:j+1) = norm([1 -1].*(x(2,:) - x(1,:))); 
            end
        elseif size(M1,1) > size(M2,1) && ~strcmp(mesh.elem_type,'TRESS')
            error('ThermoPGD:FEMVec:BadInput',['Unable to get the normal of the element ' mesh.elem_type]);
        else
            N = eye(length(wg));
        end
        
        if is_elem
            K{i} = sparse(mesh.nbNodes(),1);
            K{i}(index,1) = M2'*blkdiag(D{:})*N*M1;
        else
            K(index,1) = K(index,1) + M2'*blkdiag(D{:})*N*M1;
        end
    end
end