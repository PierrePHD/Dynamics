function K = FEMMat(mesh,odr1,odr2,fct_handle,varargin)
%FEMMat Compute the Finite Element matrix
%
%   FEMMat compute the Finite Element matrix associated to the computation
%   of int_x d^(ord1)u/dx * f(x) * d^(ord1)v/dx dx where f is a function
%   only of x given as fct_handle.
%
%   see FEMVec.
%
%   Copyright 2014 Pierre-Eric Allier

    % Input Check
    if ~isa(mesh,'mesh.Mesh') || odr1 < 0 || odr2 < 0 || odr1 > 1 || odr2 > 1 || ~isa(fct_handle,'function_handle')
    	error('ThermoPGD:FEMMat:BadInput','Bad input, check the doc.');
    end
    
    is_elem = false; % Not elementary matrix
    is_gauss2gauss = false; % Not a gauss 2 gauss matrix
    is_gauss2nodes = false; % Not a gauss 2 nodes matrix
    
    for i=1:length(varargin)
        switch varargin{i}
            case 'elementary'
                is_elem = true;
            case 'gauss2gauss'
                is_gauss2gauss = true;
            case 'gauss2nodes'
                is_gauss2nodes = true;
            otherwise
                warning('ThermoPGD:FEMMat','Unknown input argument');
        end
    end
    
    if is_gauss2gauss && is_gauss2nodes
        error('ThermoPGD:FEMMat','Error can''t return 2 kind of matrix at once');
    end
    
    % Get the specific shapes and gauss point for the element
    switch mesh.elem_type
        case 'NODE'
            shapes{1} = @(a,x) 1;
            shapes{2} = @(a,x) 0;
            jac = @(a,x) 1;
            
            xg = 1;
            wg = 1;
        case 'TRESS'
            
            shapes{1} = @(a,x) [(1-a) (1+a)]/2;
            DN = @(a,x) [-ones(size(a)) ones(size(a))]/2;
            jac = @(a,x) DN(a)*x;
            shapes{2} = @(a,x) cell2mat(cellfun(@(ai) jac(ai,x)\DN(ai),num2cell(a,2),'UniformOutput',false));
            
            xg = [0.774596669241483 0.0 -0.774596669241483]';
            wg = [0.555555555555556 0.888888888888889 0.555555555555556];
        case 'TRI'
            shapes{1} = @(a,x) [a(:,1) a(:,2) 1-a(:,1)-a(:,2)];
            DN = @(a) reshape([ones(size(a(:,1))) zeros(size(a(:,1))) -ones(size(a(:,1))) ...
                               zeros(size(a(:,1))) ones(size(a(:,1))) -ones(size(a(:,1)))]',3,[])';
            jac = @(a,x) DN(a)*x;
            shapes{2} = @(a,x) cell2mat(cellfun(@(ai) jac(ai,x)\DN(ai),num2cell(a,2),'UniformOutput',false));
            
            xg = [0.166666666666667 0.166666666666667;0.166666666666667 0.666666666666667;0.666666666666667 0.166666666666667];
            wg = [0.166666666666667 0.166666666666667 0.166666666666667];
        case 'QUAD'
            shapes{1} = @(a,x) [(a(:,1)-1)*(a(:,2)-1) (a(:,1)+1)*(a(:,2)+1) ...
                                (a(:,1)+1)*(a(:,2)-1) (a(:,1)-1)*(a(:,2)+1)]/4;
            DN = @(a) reshape([(a(:,2)-1) (a(:,2)+1) (a(:,2)-1) (a(:,2)+1) ...
                               (a(:,1)-1) (a(:,1)+1) (a(:,1)+1) (a(:,1)-1)]',4,[])';
            jac = @(a,x) DN(a)*x;
            shapes{2} = @(a,x) cell2mat(cellfun(@(ai) jac(ai,x)\DN(ai),num2cell(a,2),'UniformOutput',false));
            
            xg = [-0.57735026918962576450 -0.57735026918962576450; ...
                   0.57735026918962576450 -0.57735026918962576450; ...
                  -0.57735026918962576450  0.57735026918962576450; ...
                   0.57735026918962576450  0.57735026918962576450];
            wg = [1 1 1 1];
    end
    
    ng = length(wg)*mesh.d; % The number of gauss points times the dimension of the space
    
    if is_elem
        K = cell(mesh.nbElems(),1);
    else
        if is_gauss2gauss
            K = sparse(mesh.nbElems()*ng,mesh.nbElems()*ng);
        elseif is_gauss2nodes
            K = sparse(mesh.nbElems()*ng,mesh.nbNodes());
        else
            K = sparse(mesh.nbNodes(),mesh.nbNodes()); % We are in thermic
        end
    end
    
    convert_index = reshape(1:mesh.nbElems()*ng,ng,[])';
    
    % Assembling
    for i=1:mesh.nbElems()
        index = mesh.elems(i,:); % Since we are in thermic, the id of nodes == the index in the matrix
        
        if is_gauss2gauss
            index1 = convert_index(i,:)';
            index2 = index1;
        elseif is_gauss2nodes
            index1 = convert_index(i,:)';
            index2 = index;
        else
            index1 = index;
            index2 = index;
        end
        
        x = mesh.nodes(index,:); % Global coordinate of the node
        
        % In case of TRESS element in 2D, we need to switch to the
        % curvilligne abscisse
        if strcmp(mesh.elem_type, 'TRESS')
            x = sqrt(sum(x.^2,2));
        end
        
        if is_gauss2gauss
            M1 = 1;
        else
            M1 = shapes{odr1+1}(xg,x);
        end
        if is_gauss2gauss || is_gauss2nodes
            M2 = 1;
        else
            M2 = shapes{odr2+1}(xg,x);
        end
        
        D = cellfun(@(w,a,g) w*det(jac(a,x))*fct_handle(shapes{1}(a,x)*x),num2cell(wg(:)),num2cell(xg,2),'UniformOutput',false);

        if is_elem
            if is_gauss2gauss
                K{i} = sparse(mesh.nbElems()*ng,mesh.nbElems()*ng);
            elseif is_gauss2nodes
                K{i} = sparse(mesh.nbElems()*ng,mesh.nbNodes());
            else
                K{i} = sparse(mesh.nbNodes(),mesh.nbNodes()); % We are in thermic
            end
            K{i}(index1,index2) = M2'*blkdiag(D{:})*M1;
        else
            K(index1,index2) = K(index1,index2) + M2'*blkdiag(D{:})*M1;
        end
    end
end