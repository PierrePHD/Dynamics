classdef LinearForm
%LinearForm   A Linear Formulation representation for Finite Element Methods
%
%   Copyright 2014 Pierre-Eric Allier

    properties
        mesh; % The mesh of integration (of class Mesh)
        order; % The order of derivation of the test field 
        func_handle; % A handle to a function of the mesh
    end
    
    methods
        function obj = LinearForm(mesh,odr,func)
            if ~isa(mesh,'mesh.Mesh') || odr < 0 || odr > 1
                error('ThermoPGD:BilinearForm:BadInput','Bad input, check the doc.');
            end
            obj.mesh = mesh;
            obj.order = odr;
            obj.func_handle = func;
        end
        
        function A = assemble(obj)
            A = sparse(obj.mesh.nbNodes()); % Since we only do thermic
            for i=1:obj.mesh.nbElems()
                id = obj.indexOfElem(i);
                A(id,id) = A(id,id) + obj.matrixOfElem(i);
            end
        end
        
        function A = elementary(id)
            n = obj.mesh.nbElems();
            if nargin == 1
                if id > n
                    error('ThermoPGD:BilinearForm:BadInput','The elementary method take an optionnal integer lower than the number of elements.');
                end
                % Compute the structure containing the index and the
                % elementary matrix of the element id
                A = struct('index',obj.indexOfElem(id),'matrix',obj.matrixOfElem(id));
            else
                A = cell(n,1);
                for i=1:n
                    A{i} = obj.elementary(i);
                end
            end
        end
        
        function i = indexOfElem(obj,id)
            i = obj.mesh.elems(id,:);
        end
        
        function K = matrixOfElem(obj,id)
            switch obj.mesh.elem_type
                case 'NODE'
                    loc_coords = 1; % Local coords of the nodes
                	N{1} = @(a) ones(size(a)); % Shape function in the local basis
                    N{2} = @(a) zeros(size(a)); % Derivation of shape function in the local basis
                    
                    xg = 1; % Gauss points coordinate
                    wg = 1; % Gauss weights; 
                 
                case 'TRESS'
                    loc_coords = [-1;1]; % Local coords of the nodes
                	N{1} = @(a) [(1+a)/2 (1-a)/2]; % Shape function in the local basis
                    N{2} = @(a) [ones(size(a))/2 -ones(size(a))/2]; % Derivation of shape function in the local basis
                    
                    xg = [sqrt(1/3);-sqrt(1/3)]; % Gauss points coordinate
                    wg = [1 1]; % Gauss weights; 

                case 'TRI'
                    loc_coords = [1 0;0 0;0 1]; % Local coords of the nodes
                	N{1} = @(a) [a(:,1) a(:,2) 1-a(:,1)-a(:,2)]; % Shape function in the local basis
                    N{2} = @(a) reshape([ones(size(a(:,2))) zeros(size(a(:,2))) -a(:,2) ...
                                         zeros(size(a(:,2))) ones(size(a(:,2))) -a(:,1)]',3,[])'; % Derivation of shape function in the local basis
                    
                    xg = [1/6 1/6;1/6 2/3;2/3 1/6]; % Gauss points coordinate
                    wg = [1/6 1/6 1/6]; % Gauss weights; 

                case 'QUAD'
                    
                otherwise
                    error('ThermoPGD:BilinearForm:UnknownElem',['The element ' obj.mesh.elem_type ' is unknown.']);
            end
            J = @(a,x) N{2}(a)*x; % Jacobian of the transformation local to global
            detJ = @(a,x) cellfun(@(j) det(j),mat2cell(J(a,x),size(a,2)*ones(size(a,1),1)));
            
            % Computation of the elementary matrix
            x = obj.mesh.nodes(obj.mesh.elems(id,:),:); % Coordinates of the nodes
            if obj.mesh.d > size(loc_coords,2) % If the local space ins't the space size than the global one
                error('ThermoPGD:BilinearForm:NotYetImplemented','');
            end
            if obj.order == 0
                M1 = N{1}(xg);
            else
                M1 = cell2mat(cellfun(@(j,n) j\n,mat2cell(J(xg,x),size(xg,2)*ones(size(xg,1),1)), ...
                                        mat2cell(N{2}(xg),size(xg,2)*ones(size(xg,1),1)),'UniformOutput',false));
            end
            f = obj.func_handle(x);% Compute the field at the nodes
            
            if  
            g = N{1}(xg)*
            d = cellfun(@(w,j,g) w*j*g*obj.C,num2cell(wg(:)),num2cell(detJ(xg,x)),num2cell(g(:)),'UniformOutput',false);
            K = (M1'*blkdiag(d{:})*M2);
        end
    end
end