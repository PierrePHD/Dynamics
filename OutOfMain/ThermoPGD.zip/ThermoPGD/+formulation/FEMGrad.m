function v = FEMGrad(mesh,u,fct_handle)
%FEMGrad Compute the discret gradient of a Finite Element field.
%
%   FEMGrad compute the discret gradient of a Finite Element field u based 
%   on the mesh x. It's the computation of du/dx.
%
%   see FEMMat, FEMVec.
%
%   Copyright 2014 Pierre-Eric Allier

    % Input Check
    if ~isa(mesh,'mesh.Mesh')
    	error('ThermoPGD:FEMMat:BadInput','Bad input, check the doc.');
    end
    
    is_matrix = false;
    if nargin == 2 && isnumeric(u)
        if mesh.d == 2
            fct_handle = @(x) [1 0;0 1];
        else
            fct_handle = @(x) 1;
        end
    elseif nargin == 2 && isa(u,'function_handle')
    	fct_handle = u;
        is_matrix = true;
    elseif nargin == 2
        error('ThermoPGD:FEMMat:BadInput','Bad input, check the doc.');
    end
    
    % Get the specific shapes and gauss point for the element
    switch mesh.elem_type
        case 'TRESS'
            shapes{1} = @(a,x) [(1-a) (1+a)]/2;
            DN = @(a,x) [-ones(size(a)) ones(size(a))]/2;
            jac = @(a,x) DN(a)*x;
            shapes{2} = @(a,x) cell2mat(cellfun(@(ai) jac(ai,x)\DN(ai),num2cell(a,2),'UniformOutput',false));
            
            xg = [0.774596669241483 0.0 -0.774596669241483]';
            wg = [0.555555555555556 0.888888888888889 0.555555555555556];
        case 'TRI'
            shapes{1} = @(a,x) [a(:,1) a(:,2) 1-a(:,1)-a(:,2)];
            DN = @(a) reshape([ones(size(a(:,1))) zeros(size(a(:,1))) -ones(size(a(:,1))) ...
                               zeros(size(a(:,1))) ones(size(a(:,1))) -ones(size(a(:,1)))]',3,[])';
            jac = @(a,x) DN(a)*x;
            shapes{2} = @(a,x) cell2mat(cellfun(@(ai) jac(ai,x)\DN(ai),num2cell(a,2),'UniformOutput',false));
            
            xg = [0.166666666666667 0.166666666666667;0.166666666666667 0.666666666666667;0.666666666666667 0.166666666666667];
            wg = [0.166666666666667 0.166666666666667 0.166666666666667];
        case 'QUAD'
            shapes{1} = @(a,x) [(a(:,1)-1)*(a(:,2)-1) (a(:,1)+1)*(a(:,2)+1) ...
                                (a(:,1)+1)*(a(:,2)-1) (a(:,1)-1)*(a(:,2)+1)]/4;
            DN = @(a) reshape([(a(:,2)-1) (a(:,2)+1) (a(:,2)-1) (a(:,2)+1) ...
                               (a(:,1)-1) (a(:,1)+1) (a(:,1)+1) (a(:,1)-1)]',4,[])';
            jac = @(a,x) DN(a)*x;
            shapes{2} = @(a,x) cell2mat(cellfun(@(ai) jac(ai,x)\DN(ai),num2cell(a,2),'UniformOutput',false));
            
            xg = [-0.57735026918962576450 -0.57735026918962576450; ...
                   0.57735026918962576450 -0.57735026918962576450; ...
                  -0.57735026918962576450  0.57735026918962576450; ...
                   0.57735026918962576450  0.57735026918962576450];
            wg = [1 1 1 1];
    end
    
    ng = length(wg); % The number of gauss points
    K = sparse(mesh.d*ng*mesh.nbElems(),mesh.nbNodes()); % We are in thermic
    
    convert_index = reshape(1:size(K,1),mesh.d*ng,[])';
    
    % Assembling
    for i=1:mesh.nbElems()
        index = mesh.elems(i,:); % Since we are in thermic, the id of nodes == the index in the matrix
        
        x = mesh.nodes(index,:); % Global coordinate of the node
        
        % In case of TRESS element in 2D, we need to switch to the
        % curvilligne abscisse
        if strcmp(mesh.elem_type, 'TRESS')
            x = sqrt(sum(x.^2,2));
        end
        
        M1 = shapes{2}(xg,x);
        D = cellfun(@(a) fct_handle(shapes{1}(a,x)*x),num2cell(xg,2),'UniformOutput',false);
        
        K(convert_index(i,:)',index) = K(convert_index(i,:)',index) + blkdiag(D{:})*M1;
    end
    if is_matrix
        v = K;
    else
        v = K*u;
    end
end