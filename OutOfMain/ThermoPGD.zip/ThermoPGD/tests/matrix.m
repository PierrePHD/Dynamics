addpath('../');
eps = 10^(-12);

%% 1D matrix test
x = mesh.segmentMesh(0:1/10:1);

% Mass matrix int(u*v)
M_ex = zeros(x.nbNodes());
for i=1:(x.nbNodes()-1)
    L = norm(x.nodes(i+1,:) - x.nodes(i,:));
    M_ex([i i+1],[i i+1]) = M_ex([i i+1],[i i+1]) + L*[1/3 1/6;1/6 1/3];
end
M_fem = formulation.FEMMat(x,0,0,@(x) 1);
assert(norm(M_fem - M_ex) < eps,'1D Mass matrix computation wrong.');

% Rigidity matrix int(du/dx*dv/dx)
K_ex = zeros(x.nbNodes());
for i=1:(x.nbNodes()-1)
    L = norm(x.nodes(i+1,:) - x.nodes(i,:));
    K_ex([i i+1],[i i+1]) = K_ex([i i+1],[i i+1]) + 1/L*[1 -1;-1 1];
end
K_fem = formulation.FEMMat(x,1,1,@(x) 1);
assert(norm(K_fem - K_ex) < eps,'1D Rigidity matrix computation wrong.');

% Instationnary matrix int(du/dx*v)
K_ex = zeros(x.nbNodes());
for i=1:(x.nbNodes()-1)
    L = norm(x.nodes(i+1,:) - x.nodes(i,:));
    K_ex([i i+1],[i i+1]) = K_ex([i i+1],[i i+1]) + 1/2*[1 -1;1 -1];
end
K_fem = formulation.FEMMat(x,1,0,@(x) 1);
assert(norm(K_fem - K_ex) < eps,'1D Instationnary matrix computation wrong.');

% Conductivity matrix int(k*u*v)
K_ex = zeros(x.nbNodes());
for i=1:(x.nbNodes()-1)
    L = norm(x.nodes(i+1,:) - x.nodes(i,:));
    K_ex([i i+1],[i i+1]) = K_ex([i i+1],[i i+1]) + L*(L/12*ones(2) + x.nodes(i,1)*[1/3 1/6;1/6 1/6] + x.nodes(i+1,1)*[0 0;0 1/6]);
end
K_fem = formulation.FEMMat(x,0,0,@(x) x(1));
assert(norm(K_fem - K_ex) < eps,'1D Conductivity matrix computation wrong.');

%% 2D matrix test (TRI)
x = mesh.Mesh(2,'TRI');
%x.addNodes([0 0;3 0;0 2]);
%x.addElems([1 2 3]);
x.addNodes([0 0;3 0;0 2;3 2]);
x.addElems([1 2 3;3 2 4]);

% Mass matrix int(u*v)
M_ex = zeros(x.nbNodes());
for i=1:x.nbElems()
    index = x.elems(i,:); % In thermic, the ddl index is the nodes one
    L(1) = norm(x.nodes(index(2),:)-x.nodes(index(1),:));
    L(2) = norm(x.nodes(index(3),:)-x.nodes(index(1),:));
    L(3) = norm(x.nodes(index(3),:)-x.nodes(index(2),:));
    L1 = min(L);
    L2 = min(L(L~=L1)); 
    M_ex(index,index) = M_ex(index,index) + L1*L2*[1/12 1/24 1/24;1/24 1/12 1/24;1/24 1/24 1/12];
end
M_fem = formulation.FEMMat(x,0,0,@(x) 1);
assert(norm(M_fem - M_ex) < eps,'2D Mass matrix computation wrong.');

% Rigidity matrix int(du/dx*dv/dx) (TODO NOT WORKING FIND THE INDEX)
K_ex = zeros(x.nbNodes());
for i=1:x.nbElems()
    index = x.elems(i,:); % In thermic, the ddl index is the nodes one
    L(1) = norm(x.nodes(index(2),:)-x.nodes(index(1),:));
    L(2) = norm(x.nodes(index(3),:)-x.nodes(index(1),:));
    L(3) = norm(x.nodes(index(3),:)-x.nodes(index(2),:));
    [L, id] = sort(L);
    disp([num2str(id(1)) ';' num2str(id(2))]);
    Kelem = L(2)/(2*L(1))*[1 0 -1;0 0 0;-1 0 0] + L(1)/(2*L(2))*[0 0 0;0 1 -1;0 -1 0] + L(3)^2/(2*L(1)*L(2))*[0 0 0;0 0 0;0 0 1];
    K_ex(index,index) = K_ex(index,index) + Kelem(id(end:-1:1),id(end:-1:1));
end
K_fem = formulation.FEMMat(x,1,1,@(x) [1 0;0 1]);
assert(norm(K_fem - K_ex) < eps,'2D Rigidity matrix computation wrong.');