addpath('../'); % Add the library

import mesh.*; % Import the mesh library
import fem.*; % Import the fem library

%% Mesh
% Parameter
L = 1; % Length of the square (space)

% Create the mesh
x = Mesh(2,'TRI');
ids = x.addNodes([0 0;L 0;0 L;L L]);
x.addElems([ids(1) ids(2) ids(3);ids(2) ids(4) ids(3)]);
        
%% Problem formulation k*grad(u) + fd = 0

% Dirichlet conditions
ud = cell(1,1);
ud{1,1} = @(x) x(2) == 0;

% Conductivity condition
k = cell(1,1);
k{1,1} = @(x) [1 0;0 1];

% Specific heat 
c = cell(1,0);
% Volumic flux
fd = cell(1,0);

% Linear flux
rd = cell(1,1);
rd{1,1} = @(x) (x(2) == L)*[0 1]';

% Discrete flux
Fd = cell(4,0);

%% Solver
u_fem = femSolver({x}, c, k, ud, fd, rd, Fd, 0.5,true);

figure;
    subplot(1,2,1);
    plotOnNodes(x,u_fem.data);
    xlabel('x');
    ylabel('y');
    h = colorbar;
    xlabel(h,'u');

s_fem = error.femDualField(u_fem, k);

    subplot(1,2,2);
    plotOnElems(x,s_fem.data);
    xlabel('x');
    ylabel('y');
    h = colorbar;
    xlabel(h,'\phi');
    
s_adm = error.EETMethod(s_fem, k, fd, rd, Fd);