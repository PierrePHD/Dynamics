function u = pollutionPgdSolver(x, c, k, fd, ud, vd, m_max, l_max, no_time)
    clear global saved_residual_err_vals residual_err_plot_handle;
    d = length(x);
    disp('[-]PGD RESOLUTION');
    disp('   -> Initialization');
    
    if nargin == 8
        no_time = false;
    end
        
    % Matrix precomputation
    K = cell(d,size(c,2)+size(k,2)+size(fd,2));
    for i=1:size(c,2)
        for j=1:d
            if j == 2
                K{j,i} = formulation.FEMMat(x{j},1,0,c{j,i});
            else
                K{j,i} = formulation.FEMMat(x{j},0,0,c{j,i});
            end
        end
    end
    n = size(c,2);
    for i=1:size(k,2)
        for j=1:d
            if j == 1
                K{j,n+i} = formulation.FEMMat(x{j},1,1,k{j,i});
            else
                K{j,n+i} = formulation.FEMMat(x{j},0,0,k{j,i});
            end
        end
    end
    n = size(c,2) + size(k,2);
    for i=1:size(fd,2)
        for j=1:d
        	K{j,n+i} = formulation.FEMMat(x{j},0,0,fd{j,i});
        end
    end

    F = cell(d,1);
    n = 0;
    for i=1:size(vd,2)
        for j=1:size(K,2)
            F(:,n+j) = cellfun(@(k,s,y) k*mesh.evalOnMesh(y,s),K(:,j),vd(:,i),x(:),'UniformOutput',false);
            F{1,n+j} = -F{1,n+j}; % Don't forget the minus
        end
        n = size(F,2);
    end
    
    % Mask computation
    mask = cell(d,1);
    for j=1:d
        mask{j} = logical(mesh.evalOnMesh(x{j},ud{j,1}));
    end

    % PGD
    u = pgd.PGDRep(d);
    for i=1:size(vd,2)
        v = cellfun(@(x,f) mesh.evalOnMesh(x,f),x(:),vd(:,i),'UniformOutput',false);
        u.addMode(v{:});
    end
    S = cell(d,1);
    m = 0;
    
    % Compute and plot the residual error
    residualErr(F,u,mask);
    
    while m < m_max
        m = m + 1;
        disp('   -> New mode');   

        % Initialisation
        for j=1:d
            S{j} = ones(x{j}.nbNodes(),1);
            S{j}(mask{j}) = 0;
        end
        
        % Fixed point algorithm
        for l=1:l_max
            for j=d:-1:1
                % Solve the little problem
                S{j} = solveProb(K,F,mask,S,j);
                
                % And don't forget to norm it
                if j ~= 1
                    S{j} = S{j}./norm(S{j}); % Since it's not the space
                end
            end
        end
        
        u.addMode(S{:}); % Add a new PGD mode
        
        % Add the implied thermic flux from the last modes
        n = size(F,2);
        for i=1:size(K,2)
            F(:,n+i) = cellfun(@(k,s) k*s,K(:,i),S,'UniformOutput',false);
            F{1,n+i} = -F{1,n+i}; % Don't forget the minus
        end

        % Compute and plot the residual error
        residualErr(F,u,mask);
    end
    
end

function v = solveProb(K,F,mask,S,i)
    % Compute the Bilinear matrix A
    A = 0;
    for j=1:size(K,2)
        Ae = 1;
        for l=setdiff(1:size(K,1),i)
            Ae = Ae*S{l}'*K{l,j}*S{l};
        end
        A = A + Ae*K{i,j};
    end
    
    % Compute the Linear vector b
    b = 0;
    for j=1:size(F,2)
        be = 1;
        for l=setdiff(1:size(F,1),i)
            be = be*S{l}'*F{l,j};
        end
        b = b + be*F{i,j};
    end
    
    % Solve
    v = S{i};
    v(~mask{i}) = A(~mask{i},~mask{i})\b(~mask{i});
end

function val = normEnergetic(x,u)
    M = formulation.FEMMat(x,0,0,@(x) 1);
    val = u'*M*u;
end

function residualErr(F,u,mask)
% Evaluate the residual error and make a dynamic plot of it
    global saved_residual_err_vals;
    global residual_err_plot_handle;
    
    m = u.nbModes; % number of modes
    
    err = 0;
    for i=1:size(F,2)
        data = cellfun(@(f,m) full(f(~m)),F(:,i),mask,'UniformOutput',false);
        err = err + pgd.outProd(data{:});
    end
    err = err.^2;
    err = sqrt(sum(err(:)));
    saved_residual_err_vals = [saved_residual_err_vals err];
    if isempty(residual_err_plot_handle)
        figure;
        residual_err_plot_handle = gca;
    end
    plot(residual_err_plot_handle,0:length(saved_residual_err_vals)-1,saved_residual_err_vals(:)./saved_residual_err_vals(1),'-+');
    drawnow;
end

