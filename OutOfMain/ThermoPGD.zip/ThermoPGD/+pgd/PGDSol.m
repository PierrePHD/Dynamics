classdef PGDSol < fem.FEMSol
%PGDSol A class to represente any kind of PGD solution discretized on a
%high dimensional space
    
    methods
        function obj = PGDSol(meshes,representation)
        %PGDSol constructor (see the FEMSol constructor help) 
            obj = obj@fem.FEMSol(meshes);
            
            obj.data = cell(length(obj.meshes),1);
        end
        
        function m = nbModes(obj)
        %nbModes Return the number of PGD modes in this representation
            m = size(obj.data{1},2); % There is at least one meshes from the check in FEMSol
        end
        
        function obj = setMode(obj,data,i)
        %setMode set a PGD mode to the current object.
        %
        %    addMode(obj,{fct1,fct2,...fctd},i) where d is the dimension of the PGD
        %    space and fct, fonctions of each dimension and i the index of
        %    the mode to change. If you want to add a mode, see the addMode
        %    function.
        %
            if iscell(data) && i <= obj.nbModes() && length(data) == length(obj.meshes)
                for j=1:length(data)
                    obj.data{j}(:,i) = data{j}(:);
                end
            else
                error('ThermoPGD:PGDSol:BadInput','Bad input in the setMode function. Check the doc.');
            end
        end
        
        
        function obj = addMode(obj,data)
        %addMode Add a PGD mode to the current object.
        %
        %    addMode(obj,{fct1,fct2,...fctd}) where d is the dimension of the PGD
        %    space and fct, fonctions of each dimension.
        %
            if iscell(data) && length(data) == length(obj.meshes)
                obj.data = cellfun(@(data,x) [data x(:)],obj.data,data(:),'UniformOutput',false);
            else
                error('ThermoPGD:PGDSol:BadInput','Bad input in the addMode function. Check the doc.');
            end
        end
        
        function mode = getModes(obj,i)
        %getModes Return only the ith modes as a PGDRep object
        %
        %    vals = getModes(obj, i) where i is an integer or list of integer
        %    lower or equal than the number of PGD modes in this representation
        %
            if all(abs(i - round(i)) < eps) && max(i) <= obj.nbModes() && min(i) > 0
                mode = pgd.PGDSol(obj.meshes);
                mode.setRepresentation(obj.kind_of_rep);
                vals = cellfun(@(x) x(:,i),obj.data,'UniformOutput',false);
                mode.data = vals;
            else
                error('ThermoPGD:PGDSol:BadInput','Bad input in the getModes function. Check the doc.');
            end    
        end
        
        function vals = fullRep(obj,ids)
        % Return the full representation of the solution over the whole space
        %
        %   fullRep(obj) return the full representation.
        %   
        %   fullRep(obj, ids) return the full tensor of the
        %   representation where ids are a cell of same size than the
        %   representation one of value to eval the output. Usefull for
        %   computing only the dependency of one parameter where the other
        %   are fixed to a certain value.
        %
        %   Example :
        %       a.fullRep({[],2})
            if nargin <= 1
                ids = cell(obj.dim(),1);
            elseif length(ids) ~= obj.dim()
                error('ThermoPGD:PGDRep:BadInput','Bad input in the fullRep function. Check the doc.');
            end
            
            % Then we need to set (:) for the empty index return
            for i=1:obj.dim()
                if isempty(ids{i})
                    ids{i} = 1:size(obj.data{i},1);
                end
            end
            ids = ids(:);

            if size(obj.data{1},2) > 0
                extract = cellfun(@(x,id) x(id,1),obj.data,ids,'UniformOutput',false);
                vals = pgd.outProd(extract{:});
                for i=2:size(obj.data{1},2)
                    extract = cellfun(@(x,id) x(id,i),obj.data,ids,'UniformOutput',false);
                    vals = vals + pgd.outProd(extract{:});
                end
            end
        end
        
        function obj = setData(obj,data)
        % Allow to set the value of the solution
            error('ThermoPGD:PGDSol:Forbidden','In PGD mode, the setData function can''t be used.');
        end
    end
    
end