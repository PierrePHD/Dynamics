function u = pgdSolver(x, c, k, ud, fd, rd, Fd, m_max, l_max, no_time)
    clear global saved_residual_err_vals residual_err_plot_handle;
    d = length(x);
    disp('[-]PGD RESOLUTION');
    disp('   -> Initialization');
    
    if nargin == 9
        no_time = false;
    else
        c = cell(d,0); % Just in case
    end
        
    % Matrix precomputation
    K = cell(d,size(c,2)+size(k,2));
    n = size(c,2);
    for i=1:n
        for j=1:d
            if j == 2
                K{j,i} = formulation.FEMMat(x{j},1,0,c{j,i});
            else
                K{j,i} = formulation.FEMMat(x{j},0,0,c{j,i});
            end
        end
    end
    for i=1:size(k,2)
        for j=1:d
            if j == 1
                K{j,n+i} = formulation.FEMMat(x{j},1,1,k{j,i});
            else
                K{j,n+i} = formulation.FEMMat(x{j},0,0,k{j,i});
            end
        end
    end

    F = cell(d,size(fd,2)+size(rd,2)+size(Fd,2));
    n = size(fd,2);
    for i=1:n
        for j=1:d
            F{j,i} = formulation.FEMVec(x{j},0,fd{j,i});
        end
    end
    for i=1:size(rd,2)
        for j=1:d
            if j == 1
                F{j,n+i} = formulation.FEMVec(x{j}.freeBoundary(),0,rd{j,i});
            else
                F{j,n+i} = formulation.FEMVec(x{j},0,rd{j,i});
            end
        end
    end
    n = n + size(rd,2);
    for i=1:size(Fd,2)
        for j=1:d
            if j == 1
                F{j,n+i} = formulation.FEMVec(x{j}.freeBoundary().freeBoundary(),0,Fd{j,i});
            else
                F{j,n+i} = formulation.FEMVec(x{j},0,Fd{j,i});
            end
        end
    end
    
    % Mask computation
    mask = cell(d,1);
    for j=1:d
        mask{j} = logical(mesh.evalOnMesh(x{j},ud{j,1}));
    end

    % PGD
    u = pgd.PGDSol(x);
    S = cell(d,1);
    m = 0;
    
    % Compute and plot the residual error
    residualErr(F,u,mask);
    
    while m < m_max
        m = m + 1;
        disp('   -> New mode');   

        % Initialisation
        for j=1:d
            S{j} = ones(x{j}.nbNodes(),1);
            S{j}(mask{j}) = 0;
        end
        
        % Fixed point algorithm
        for l=1:l_max
            for j=[2:d 1]
                % Solve the little problem
                S{j} = solveProb(K,F,mask,S,j);
                
                % And don't forget to norm it
                if j ~= 1
                    S{j} = S{j}./norm(S{j}); % Since it's not the space
                end
            end
        end
        
        u.addMode(S(:)); % Add a new PGD mode
        
        % Orthogonalization of required
        if false
            n = size(fd,2) + size(rd,2) + size(Fd,2);
            if m == 1
                b = S{1};
            else
                b = [b pgd.ortho(b,S{1}(:,end),@(u,v) u'*formulation.FEMMat(x{1},0,0,@(x) 1)*v)];
                u = recompute(K,F(:,1:n),mask,b,u,l_max); % Fixed point algorithm to recompute the other modes
            end
            % Add the implied thermic flux from all the last modes
            F = F(:,1:n); % Erase old values
            for l=1:m
                for i=1:size(K,2)
                    F(:,n+i) = cellfun(@(k,v) k*v,K(:,i),u.getModes(l),'UniformOutput',false);
                    F{1,n+i} = -F{1,n+i}; % Don't forget the minus
                end
                n = size(F,2);
            end
        else
            % Add the implied thermic flux from the last modes
            n = size(F,2);
            for i=1:size(K,2)
                F(:,n+i) = cellfun(@(k,s) k*s,K(:,i),S,'UniformOutput',false);
                F{1,n+i} = -F{1,n+i}; % Don't forget the minus
            end
        end

        % Compute and plot the residual error
        residualErr(F,u,mask);
    end
    
end

function v = solveProb(K,F,mask,S,i)
    % Compute the Bilinear matrix A
    A = 0;
    for j=1:size(K,2)
        Ae = 1;
        for l=setdiff(1:size(K,1),i)
            Ae = Ae*S{l}'*K{l,j}*S{l};
        end
        A = A + Ae*K{i,j};
    end
    
    % Compute the Linear vector b
    b = 0;
    for j=1:size(F,2)
        be = 1;
        for l=setdiff(1:size(F,1),i)
            be = be*S{l}'*F{l,j};
        end
        b = b + be*F{i,j};
    end
    
    % Solve
    v = S{i};
    v(~mask{i}) = A(~mask{i},~mask{i})\b(~mask{i});
end

function val = normEnergetic(x,u)
    M = formulation.FEMMat(x,0,0,@(x) 1);
    val = u'*M*u;
end

function residualErr(F,u,mask)
% Evaluate the residual error and make a dynamic plot of it
    global saved_residual_err_vals;
    global residual_err_plot_handle;
    
    m = u.nbModes(); % number of modes
    
    err = 0;
    for i=1:size(F,2)
        data = cellfun(@(f,m) full(f(~m)),F(:,i),mask,'UniformOutput',false);
        err = err + pgd.outProd(data{:});
    end
    err = err.^2;
    err = sqrt(sum(err(:)));
    saved_residual_err_vals = [saved_residual_err_vals err];
    if isempty(residual_err_plot_handle)
        figure;
        residual_err_plot_handle = axes;
    end
    plot(residual_err_plot_handle,0:m,saved_residual_err_vals(:)./saved_residual_err_vals(1),'-+');
    drawnow;
end

function u = recompute(K,F,mask,b,u,l_max)
% Recompute a PGD solution from the problem defined by K,F and mask from
% the orthognal basis b of the PGD solution u.
    disp('   -> Orthogonalization and recomputing');
    d = size(K,1);
    m = u.nbModes();
    
    % Set the orthogonal basis as the space solution
    u.data{1} = b; 
    
    % Recompute the solution
    for l=1:l_max*m
        for i=1:m
            % Compute the implied thermic flux from the other modes
            F_tmp = F(:,1:end);
            n = size(F_tmp,2);
            for j=setdiff(1:m,i)
                for o=1:size(K,2)
                    F_tmp(:,n+o) = cellfun(@(k,v) k*v,K(:,o),u.getModes(j),'UniformOutput',false);
                    F_tmp{1,n+o} = -F_tmp{1,n+o};
                end
                n = size(F_tmp,2);
            end

            % Initialized functions of the i-th mode
            S = cellfun(@(v) v(:,i),u.data,'UniformOutput',false);
            
            % Local Fixed point 
            for j=d:-1:2
                % Solve the little problem
                S{j} = solveProb(K,F_tmp,mask,S,j);
            end
            
            % Saved values
            u.data(2:end) = cellfun(@(v,s) [v(:,1:i-1) s v(:,i+1:end)],u.data(2:end),S(2:end),'UniformOutput',false);
        end
    end
end
