function [v,weights] = ortho(b,u,sp)
% Compute the Grams-Schmidt of the vector u respect to the base b with the
% scalar product funtion sp(a,b) = <a,b> such that :
%    v = u - \sum_{i=1}^{length(b)} <u,b_i>*b_i/<b_i,b_i>

    weights = zeros(size(b,2),1);
    v = u;

    for i=1:size(b,2)
        weights(i) = sp(u,b(:,i))/sp(b(:,i),b(:,i));
        v = v - weights(i)*b(:,i);
    end
end