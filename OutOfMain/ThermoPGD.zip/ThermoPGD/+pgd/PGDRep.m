classdef PGDRep < handle
%PGDRep A class to represente a PGD solution discretized
    properties
        dim = 0;% The PGD dimension
        data; % A cell structur to hold all the data
    end
    
    methods
        function obj = PGDRep(dim)
        %PGDRep constructor of a PGD representation
        %
        %   PGDRep(d) where d is the dimension of the PGD space that can't
        %   be lower than 1.
        %
            if dim <= 0
                error('ThermoPGD:PGDRep:BadInput','The dimension in the constructor can''t be lower than 1.');
            end
            obj.dim = dim;
            obj.data = cell(dim,1);
        end
        
        function obj = addMode(obj,varargin)
        %addMode Add a PGD mode to the current object.
        %
        %    addMode(obj,fct1,fct2,...fctd) where d is the dimension of the PGD
        %    space and fct, fonctions of each dimension.
        %
            if length(varargin) == obj.dim
                obj.data = cellfun(@(data,x) [data x(:)],obj.data,varargin(:),'UniformOutput',false);
            else
                error('ThermoPGD:PGDRep:BadInput','');
            end
        end
        
        function mode = getModes(obj,i)
        %getModes Return only the ith modes as a PGDRep object
        %
        %    vals = getModes(obj, i) where i is an integer or list of integer
        %    lower or equal than the number of PGD modes in this representation
        %
            if i <= size(obj.data{1},2)
                mode = pgd.PGDRep(obj.dim);
                vals = cellfun(@(x) x(:,i),obj.data,'UniformOutput',false);
                mode.addMode(vals{:});
            else
                error('ThermoPGD:PGDRep:BadInput','');
            end
        end
        
        function m = nbModes(obj)
        %nbModes Return the number of PGD modes in this representation
        %
            m = size(obj.data{1},2); % From the constructor, data{1} exist.
        end
        
        function vals = fullTensor(obj,ids)
        %return the full tensor of the PGD representation
        %
        %   fullTensor(obj) return the full tensor of the PGD representation.
        %   
        %   fullTensor(obj, ids) return the full tensor of the PGD
        %   representation where ids are a cell of same size than the PGD
        %   representation one of value to eval the output. Usefull for
        %   computing only the dependency of one parameter where the other
        %   are fixed to a certain value.
        %
        %   Example :
        %       a = PGDRep(2);
        %       a.addMode(1:3,1:4);
        %       a.fullTensor({[],2})
        %
            if nargin <= 1
                ids = cell(obj.dim,1);
            end
            % Then we need to set (:) for the empty index return
            for i=1:obj.dim
                if isempty(ids{i})
                    ids{i} = 1:size(obj.data{i},1);
                end
            end
            ids = ids(:);

            if size(obj.data{1},2) > 0
                extract = cellfun(@(x,id) x(id,1),obj.data,ids,'UniformOutput',false);
                vals = pgd.outProd(extract{:});
                for i=2:size(obj.data{1},2)
                    extract = cellfun(@(x,id) x(id,i),obj.data,ids,'UniformOutput',false);
                    vals = vals + pgd.outProd(extract{:});
                end
            else
                error('ThermoPGD:PGDRep:BadInput','');
            end
        end
        
        
    end 
end