function plotPGDSol(meshes,u,varargin)
%plotPGDSol Plots a PGD Solution
% 
%
%   See also Mesh, patch properties.

%   Copyright 2014 Pierre-Eric Allier (LMT)  

    % Check inputs
    narginchk(2,inf);
    if isa(meshes, 'cell')
        d = length(meshes); % Dimension of the PGD spaces
    else
        error('ThermoPGD:plotPGDSol:BadInputs','Bad inputs arguments, check the doc.');
    end
    for i=1:d
        if ~isa(meshes{i}, 'mesh.Mesh')
            error('ThermoPGD:plotPGDSol:BadInputs','Bad inputs arguments, check the doc.');
        end
    end
    if ~isa(u,'pgd.PGDRep') || u.dim ~= d
        error('ThermoPGD:plotPGDSol:BadInputs','Bad inputs arguments, check the doc.');
    end

    % Select the correct plot function
    switch meshes{1}.d
        case 1
            plot_handle = @(fig,x,u) plot(fig,x.nodes(:,1),u);
        case 2
            plot_handle = @(fig,x,u) mesh.plotOnNodes(x,u,'Parent',fig);
        otherwise
            error('ThermoPGD:plotPGDSol:BadInput','The space mesh dimension should be below or equal to 2.');
    end
    
    % Optionnal input (TODO)
    i = 1;
    while i < nargin - 2
        % String command as 'title','xlabel' ...
        switch varargin{i}
            case 'xlabel'
                if length(varargin{i+1}) == d && iscellstr(varargin{i+1})
                    x_label = varargin{i+1};
                else
                    warning('ThermoPGD:plotPGDSol:BadInput',['The associate xlabel variable should be a string cell array of dimension equal to ' num2str(d) '.']);
                end
                i = i + 2;
                
            case 'title'
                if ischar(varargin{i+1})
                    title = varargin{i+1};
                else
                    warning('ThermoPGD:plotPGDSol:BadInput','The associate title variable should be a string.');
                end
                i = i + 2;
            case 'ylabel'
                if ischar(varargin{i+1})
                    y_label = varargin{i+1};
                else
                    warning('ThermoPGD:plotPGDSol:BadInput','The associate zlabel variable should be a string.');
                end
                i = i + 2;
            case 'fixedaxis'
                if isa(varargin{i+1},'logical')
                    fixed_axis = varargin{i+1};
                else
                    warning('ThermoPGD:plotPGDSol:BadInput','The associate fixedaxis variable should be a logical one.');
                end
                i = i + 2;
            otherwise
                warning('ThermoPGD:plotPGDSol:BadInput',['Undefined ' varargin{i} ' field.']);
                i = i+1;
        end
    end
    
    % Default Optionnal input
    if ~exist('x_label','var')
        x_label = cell(d,1);
        for i=1:d
            x_label{i} = num2str(i);
        end
    end
    if ~exist('y_label','var')
        y_label = '';
    end
    if ~exist('title','var')
        title = '';
    end
    if ~exist('fixed_axis','var')
        fixed_axis = false;
    end
    
    % Compute the limits
    if fixed_axis
        v = u.fullTensor();
        lims = [min(v(:)) max(v(:))];
    end
    
    % Build GUI
    figH = figure('Units', 'Pixels', 'Name', title, 'ResizeFcn' , @resizeFcn);
    axesH = axes('Units', 'Pixels');

    textH = cell(d+1,1);
    sliderH = cell(d+1,1);
    buttonH = cell(d+1,1);

    % Param and time sliders
    for i=2:d
        coor = meshes{i}.nodes(:,1);
        textH{i} = uicontrol(      ...
          'Style'     , 'Text'   , ...
          'Units'     , 'Pixels' , ...
          'String'    , x_label{i});
        if length(coor) == 1
            slider_step = [1 1];
        else
            slider_step = [1 1]/(length(coor)-1);
        end
        sliderH{i} = uicontrol(                ...
          'Style'     , 'Slider'             , ...
          'Units'     , 'Pixels'             , ...
          'SliderStep', slider_step          , ...
          'Min'       , 1                    , ...
          'Max'       , length(coor)         , ...
          'Value'     , 1                    , ...
          'TooltipString', num2str(min(coor)), ...
          'Callback'  , {@sliderCallback,i}     );
        buttonH{i} = uicontrol(           ...
          'Style'     , 'Pushbutton'    , ...
          'Units'     , 'Pixels'        , ...
          'String'    , '>'             , ...
          'Callback'  , {@playButtonCallback,i});
    end
    is_played = 0;
    ids = num2cell(ones(d+1,1));

    % Modes sliders
    meshes = {meshes{:} mesh.segmentMesh(1:u.nbModes())};
    ids{end} = u.nbModes();

    sum_modes = uicontrol(          ...
        'Style'     , 'togglebutton', ...
        'Units'     , 'Pixels'      , ...
        'Min'       , 0             , ...
        'Max'       , 1             , ...
        'Value'     , 1             , ...
        'String'    , '+'           );

    if u.nbModes() > 1
        textH{end} = uicontrol(     ...
          'Style'     , 'Text'  , ...
          'Units'     , 'Pixels', ...
          'String'    , 'm'     );
        sliderH{end} = uicontrol(           ...
          'Style'     , 'Slider'          , ...
          'Units'     , 'Pixels'          , ...
          'SliderStep', slider_step       , ...
          'Min'       , 1                 , ...
          'Max'       , u.nbModes()      , ...
          'Value'     , u.nbModes()      , ...
          'TooltipString', num2str(1)     , ...
          'Callback'  , {@sliderCallback,i+1});
        buttonH{end} = uicontrol(           ...
          'Style'     , 'Pushbutton'      , ...
          'Units'     , 'Pixels'          , ...
          'String'    , '>'               , ...
          'Callback'  , {@playButtonCallback,i+1});
    else
        set(sum_modes,'Visible','off');
    end

    % Plot
    plotData();
    
    %% callback functions
    function resizeFcn(varargin)
        %resizeFcn Figure resize callback
        %   Adjust object positions so that they maintain appropriate
        %   proportions
        
        % definition of size
        border_x = 20;
        border_ui = 10;
        border_y = 20;
        
        ui_height = 15;
        button_width = 50;
        text_width = 20;
        
        % figure size
        fP = get(figH, 'Position');
        
        for j=1:length(sliderH)-1
            set(textH{length(sliderH) - j}, 'Position', [border_x, border_y + (border_ui+ui_height)*(j-1), text_width, ui_height]);
            set(sliderH{length(sliderH) - j}, 'Position', [border_x+border_ui+text_width, border_y + (border_ui+ui_height)*(j-1), fP(3)-2*border_x-2*border_ui-button_width-text_width, ui_height]);
            set(buttonH{length(sliderH) - j}, 'Position', [fP(3)-border_x-button_width, border_y + (border_ui+ui_height)*(j-1), button_width, ui_height]);
        end
        if u.nbModes() > 1
            set(textH{end}, 'Position', [border_x, fP(4)- border_y - ui_height, text_width, ui_height]);
            set(sliderH{end}, 'Position', [border_x+border_ui+text_width, fP(4)- border_y - ui_height, fP(3) - 2*border_x-3*border_ui-2*button_width-text_width, ui_height]);
            set(sum_modes, 'Position', [fP(3)-border_x-border_ui-2*button_width, fP(4)- border_y - ui_height, button_width, ui_height]);
            set(buttonH{end}, 'Position', [fP(3)-border_x-button_width, fP(4)- border_y - ui_height, button_width, ui_height]);
        end
        set(axesH  , 'Position', [border_x+text_width, border_y + (border_ui+ui_height)*d, fP(3)-2*border_x-button_width-text_width, fP(4)- 3*border_y - (border_ui+ui_height)*(d+1)]);
    end

    function sliderCallback(varargin)
        %sliderCallback Slider callback
        %	Modifies the parameter
        
        coef = round(get(varargin{1}, 'Value'));
        id = varargin{3};
        
        coor = meshes{id}.nodes(:,1);
        [~,ids{id}] = min(abs(coor - coor(coef)));
        set(sliderH{id},'TooltipString', num2str(coor(ids{id})));
        set(sliderH{id},'Value',ids{id});
        
        plotData();
    end

    function playButtonCallback(varargin)
        %playButtonCallback Button callback
        % Play/stop the update
        
        id = varargin{3};
        
        if is_played == id
            stop();
        else
            if is_played ~=0
                stop();
            end
            is_played = id;
            play();
        end
    end

    function play()
        % Update frequently the figure
        if is_played ~= 0 && ishandle(axesH)
            set(buttonH{is_played},'String','||');
            coor = meshes{is_played}.nodes;
            if length(coor) ~= ids{is_played}
                ids{is_played} = ids{is_played} + 1;
            else
                stop();
                return;
            end
            set(sliderH{is_played},'TooltipString', num2str(coor(ids{is_played})));
            set(sliderH{is_played},'Value',ids{is_played});
            
            plotData();
            
            pause(0.3);
            play();
        end
    end

    function stop()
        % Stop the update frequently the figure
        set(buttonH{is_played},'String','>');
        is_played = 0;
    end

    function plotData()
        % Plot the data
        if get(sum_modes,'Value')
%             for l=1:ids{end}
%                 w = u{1}(:,l);
%                 for j=2:d
%                     w = w.*u{j}(ids{j},l);
%                 end
%                 v = v + w;
%             end
            v = u.fullTensor({[] ids{2:end-1}});
        else
            v = u.getModes(ids{end}).fullTensor({[] ids{2:end-1}});
%             
%             v = u{1}(:,ids{end});
%             for j=2:d
%                 v = v.*u{j}(ids{j},ids{end});
%             end
        end
        plot_handle(axesH, meshes{1}, v);
        
        xlabel(axesH,x_label{1});
        
        if meshes{1}.d == 1
            if fixed_axis
                set(axesH,'YLim',lims + [-1 1]*max(abs(lims))/100);
            end
            ylabel(axesH,y_label);
        else
            bar = colorbar;
            xlabel(bar,y_label);
            if fixed_axis
                caxis(lims);
            end
        end
    end
end