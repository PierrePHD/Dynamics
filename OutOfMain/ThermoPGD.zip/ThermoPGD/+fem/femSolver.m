function U = femSolver(x, c, k, ud, fd, rd, Fd, theta, no_time)
%femSolver Compute the Finite Element Solution for a Thermic Problem
%
%
    d = length(x);
    disp('[-]FEM RESOLUTION');
    disp('   -> Initialization');
    
    if nargin == 8
        no_time = false;
    end

    % Matrix precomputation
    K = cell(d,size(c,2)+size(k,2));
    n = size(c,2);
    for i=1:n
        for j=1:d
            if j == 1
                K{j,i} = formulation.FEMMat(x{j},0,0,c{j,i});
            elseif j == 2 && ~no_time
                K{j,i} = 2;
            else
                K{j,i} = mesh.evalOnMesh(x{j},c{j,i});
            end
        end
    end
    for i=1:size(k,2)
        for j=1:d
            if j == 1
                K{j,n+i} = formulation.FEMMat(x{j},1,1,k{j,i});
            elseif j == 2 && ~no_time
                K{j,n+i} = 1;
            else
                K{j,n+i} = mesh.evalOnMesh(x{j},k{j,i});
            end
        end
    end

    F = cell(d,size(fd,2)+size(rd,2)+size(Fd,2));
    n = size(fd,2);
    for i=1:n
        for j=1:d
            if j == 1
                F{j,i} = formulation.FEMVec(x{j},0,fd{j,i});
            else
                F{j,i} = mesh.evalOnMesh(x{j},fd{j,i});
            end
        end
    end
    for i=1:size(rd,2)
        for j=1:d
            if j == 1
                F{j,n+i} = formulation.FEMVec(x{j}.freeBoundary(),0,rd{j,i});
            else
                F{j,n+i} = mesh.evalOnMesh(x{j},rd{j,i});
            end
        end
    end
    n = n + size(rd,2);
    for i=1:size(Fd,2)
        for j=1:d
            if j == 1
                F{j,n+i} = formulation.FEMVec(x{j}.freeBoundary().freeBoundary(),0,Fd{j,i});
            else
                F{j,n+i} = mesh.evalOnMesh(x{j},Fd{j,i});
            end
        end
    end
    
    % Mask computation
    mask = cell(d,1);
    for j=1:d
        mask{j} = logical(mesh.evalOnMesh(x{j},ud{j,1}));
    end

    % Compute a combination array of extra coordinates
    dims = cellfun(@(x) x.nbNodes(),x,'UniformOutput',false);
    if (length(dims) == 2 && ~no_time) || (length(dims) == 1 && no_time)
        id_params = cell(1);
    elseif (length(dims) == 2 && no_time) || (length(dims) == 3 && ~no_time)
        id_params = cell(dims{end},1);
    else
        if no_time
            id_params = cell(dims{2:end});
        else
            id_params = cell(dims{3:end});
        end
    end
    for i=1:length(id_params(:))
        id_params{i} = ind(size(id_params),i);
    end
    
    % Wa assume that the Dircihlet condition are CA0 so V = 0;
    
    disp('   -> Resolution');
    % Then we solve the problem for W = U - V 
    W = cellfun(@(k) solver(x,K,F,mask,k,theta,no_time),id_params,'UniformOutput',false);
    
    % Reshape the solution
    U = fem.FEMSol(x);
    if length(x) > 1
        U.setData(reshape(cell2mat(W(:)'),[dims{:}])); % Turn W into a full matrix
    else
        U.setData(W{1});
    end
        
end

function U = solver(mesh,B,L,mask,ids,theta, no_time)
%SOLVER Solution of a FEM problem for a specific couple of parameter.
%

    % Assembling the 1st member
    K = cell(2,1);
    for i=1:size(B,2)
        if ~no_time
            tmp = 1;
            for j=3:size(B,1)
                tmp = tmp*B{j,i}(ids(j-2));
            end
            if isempty(K{B{2,i}})
                K{B{2,i}} = tmp*B{1,i};
            else
                K{B{2,i}} = K{B{2,i}} + tmp*B{1,i};
            end
        else
            tmp = 1;
            for j=2:size(B,1)
                tmp = tmp*B{j,i}(ids(j-1));
            end
            if isempty(K{1})
                K{1} = tmp*B{1,i};
            else
                K{1} = K{1} + tmp*B{1,i};
            end
        end
    end

    % Assembling the 2nd member
    F = 0;
    for i=1:size(L,2)
        if ~no_time
            tmp = 1;
            for j=3:size(L,1)
                tmp = tmp*L{j,i}(ids(j-2));
            end
            F = F + tmp*L{1,i}*L{2,i}';
        else
            tmp = 1;
            for j=2:size(L,1)
                tmp = tmp*L{j,i}(ids(j-1));
            end
            F = F + tmp*L{1,i};
        end
    end

    % Solving
    if ~no_time
        U = zeros(mesh{1}.nbNodes(),mesh{2}.nbNodes()); % since we are in thermic
        fnew = F(:,1);
        for t = 2:mesh{2}.nbNodes()
            dt = mesh{2}.nodes(t) - mesh{2}.nodes(t-1);
            G = K{2} + theta*dt*K{1};

            fold = fnew;
            fnew = F(:,t);
            f = fold + theta*(fnew-fold);
            b = (K{2}-(1-theta)*dt*K{1})*U(:,t-1) + dt*f;
            U(~mask{1},t) = G(~mask{1},~mask{1})\b(~mask{1});
        end
    else
        U = zeros(mesh{1}.nbNodes(),1);
        U(~mask{1}) = K{1}(~mask{1},~mask{1})\F(~mask{1});
    end
end


function id = ind(siz,ndx)
%IND Multiple subscripts from linear index.
%   IND is used to determine the equivalent subscript values
%   corresponding to a given single index into an array.
%
    m = length(siz);
    id = zeros(m,1);
    k = [1 cumprod(siz(1:end-1))];

    for i=m:-1:1
        vi = rem(ndx-1, k(i)) + 1;         
        vj = (ndx - vi)/k(i) + 1; 
        id(i) = vj; 
        ndx = vi;     
    end
end