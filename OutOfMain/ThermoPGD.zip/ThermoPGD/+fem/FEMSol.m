classdef FEMSol < handle
%FEMSol A class to represente any kind of FEM solution discretized on a
%high dimensional space
    properties
        meshes; % The meshes support of the solution
        kind_of_rep; % The type of representation of the solution on each mesh (At the nodes or on the elements)
        data; % A structure to hold all the data
    end
    
    methods
        function obj = FEMSol(meshes)
        %FEMSol constructor 
        %
        %   FEMSol(meshes) where meshes is a cell of mesh object.
        %
            % Check inputs
            if iscell(meshes) && all(cellfun(@(s) isa(s,'mesh.Mesh'),meshes))
                obj.meshes = meshes(:);
                obj.kind_of_rep = cellfun(@(x) 'Nodes',cell(length(meshes),1),'UniformOutput',false);
            else
                error('ThermoPGD:FEMSol:BadInput','The constructor input should be a cell array of mesh object.');
            end
        end
        
        function setRepresentation(obj,rep)
        %setRepresentation
        %   setRepresentation(obj, rep) where the rep is a cell of string 
        %   of values in [''Nodes'',''Elems''] of the same size than the 
        %   meshes size.    
        %
            if iscell(rep) && length(rep) <= length(obj.meshes) && ...
               all(cellfun(@(s) strcmpi(s,'Nodes') || strcmpi(s,'Elems'),rep)) 
                obj.kind_of_rep(1:length(rep)) = rep;
            else
                error('ThermoPGD:FEMSol:BadInput','The setRepresentation input should be a cell of string values of [''Nodes'',''Elems''] of the same size than the 1st input.');
            end
        end
        
        function n = dim(obj)
        % Return the dimension of the problem
            n = length(obj.meshes);
        end
        
        function vals = fullRep(obj,ids)
        % Return the full representation of the solution over the whole space
        %
        %   fullRep(obj) return the full representation.
        %   
        %   fullRep(obj, ids) return the full tensor of the
        %   representation where ids are a cell of same size than the
        %   representation one of value to eval the output. Usefull for
        %   computing only the dependency of one parameter where the other
        %   are fixed to a certain value.
        %
        %   Example :
        %       a.fullRep({[],2})
        %
            if nargin <= 1
                vals = obj.data;
            elseif length(ids) == obj.dim()
                % Then we need to set (:) for the empty index return
                for i=1:obj.dim()
                    if isempty(ids{i})
                        ids{i} = 1:size(obj.data,i);
                    end
                end
                vals = obj.data(ids{:});
            else
                error('ThermoPGD:FEMRep:BadInput','Bad input in the fullRep function. Check the doc.');
            end
        end
        
        function obj = setData(obj,data)
        % Allow to set the value of the solution
            
            % Commented since we don't known the number of gauss point per
            % elements in case of an element definition
        
            %dims = cellfun(@(x,rep) strcmpi(rep,'Nodes')*x.nbNodes()+strcmpi(rep,'Elems')*x.nbElems(),obj.meshes,obj.kind_of_rep)';
            %correct_dims = size(data);
            %if length(dims) == length(correct_dims) && all(dims == correct_dims) % Check size
                obj.data = data;
            %else
            %    error('ThermoPGD:FEMSol:BadDataSize','In setData, the input should have the correct size.');
            %end
        end
    end
    
end