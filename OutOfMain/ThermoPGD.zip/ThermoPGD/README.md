# ThermoPGD

Matlab code for the Proper Generelized Decomposition (PGD) Finite Element Method for High Dimension Physical Thermic Problems. For now only works for 1D or 2D domains with specific elements (see below).

This code is part of my PhD thesis.

## What's the PGD method ?

The PGD method is a method proposed by P. Chinesta and P. Ladevèze where the unknown solution of Ordinal Differential Equations (ODE) \\(u\\), that can depend not only in space \\(\mathbf{x}\\) and time \\(t\\) but also in materials, geometric, limit conditions strength ... parameter \\(\mathbf{p}\\), is looking under the form of variable separations:

\\[ u\left(\mathbf{x}, t, \mathbf{p}\right) = \sum_{i=1}^{\infty} \left[\psi_i\left(\mathbf{x}\right) \cdot \lambda_i\left(t\right) \cdot \prod_{j=1}^{d} \gamma_{i.j}\left(p_j\right)\right] \\]

A such hypothesis, allow to deal with the *curse of dimensionality* reducing in theory the computation time for High Dimension Problems.

## What that code allow to do ?
This code use the PGD assumption on Thermic problems in 1D/2D only. It use the Finite Element MEthod (FEM) as the numerical approximation to compute the solution of the problem.

The elements implemented here are:

- Tress of 1st order that can be used in 1D or 2D;
- Triangles of 1st order;
- Quadrangles of 1st order.

You can also load a GMSH mesh file (both version 1 and 2). Other files formats aren't supported, you need to implement it. 

## Licence

Copyright 2014 Pierre-Eric Allier (LMT-Cachan)

Licensed under the Apache License, Version 2.0: [http://www.apache.org/licenses/LICENSE-2.0] (http://www.apache.org/licenses/LICENSE-2.0)

## TODO

- Comprendre ce qui ne marche pas code ludo
    + erreur dans le code ? -> OUI, TRESS fonctions de forme pas dans le bon ordre
    + orthogonalisation ? -> OK, mais partiellement efficace. Quel produit scalaire ??
- Cas test de pollution
    + Problem EF -> OK, mauvais signe car formulation variationnelle -k 
    + Problem PGD -> Codé, mais vérifier les CLs
- Erreur
    + Vérifier construction de champs sigma en PGD et EF
        * Reprendre des cas test précédements calculé dont on connait la solution
    + Calcul de champs admissible
        * Maillage
        * Code (mélanger 1D et 2D)
    + Evaluation de l'erreur
        * Capacité de l'évaluer pour chaques modes/ou pas/global
- Rafinnement
- Problemes adjoints

A + long terme:
- Definition StationnaryProblem / InstationnaryProblem (modifier le code pour prendre en compte si temps ou pas)
- Ajout des elements de degrées supérieurs
- Capacité de calculer l'erreur pour chaques modes / ou pas / global


