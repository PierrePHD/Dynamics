function val = evalOnMesh(mesh, handle)
%evalOnMesh Evaluation of a function over a Mesh object
%   evalOnMesh allow to evaluate a function handle over a Mesh object.
%
%   values = evalOnMesh(mesh, function_handle) Evaluate the function given 
%   in function_handle over the Mesh object mesh. The function take as
%   parameter a vector x representing the coordinates of a mesh node, and 
%   should return the value on it or the vector of values on it in case of 
%   a vector evaluation.
%
%   Example:
%       % Create a mesh
%       x = mesh.Mesh(2,'TRI');
%       x.addNodes([0 0;1 0;0 1;1 1]);
%       x.addElems([1 2 3;2 4 3]);
%       % Since we are in 2D, the evaluated function is actually a 2 value
%       % vector on each mesh nodes.
%   	evalOnMesh(x, @(x) [x(1) x(2)]); 
%
%   see also Mesh.
%
%   Copyright 2014 Pierre-Eric Allier (LMT)

    % Check inputs
    if ~isa(handle,'function_handle') || ~isa(mesh,'mesh.Mesh')
        error('ThermoPGD:evalOnMesh:BadInput','The eval function take as input a mesh and a handle function of x.');
    end

    % Eval the function
    val = cell2mat(cellfun(@(x) reshape(handle(x),1,[]), num2cell(mesh.nodes,2),'UniformOutput',false));
end