function hh = plotMesh(mesh,varargin)
%plotMesh Plots a Mesh object
%
%   plotMesh(mesh) displays the elements contained in the Mesh object mesh.
%
%   plotMesh(...,COLOR) uses the string COLOR as the line color.
%
%   H = plotMesh(...) returns a vector of handles to the displayed 
%   elements.
%
%   plotMesh(...,'param','value','param','value'...) allows additional
%   line param/value pairs to be used when creating the plot.
%
%   Example 1:
%       % Create the mesh
%       x = mesh.Mesh(2,'TRI');
%       x.addNodes([0 0;1 0;0 1;1 1]);
%       x.addElems([1 2 3;2 4 3]);
%       % Plot it with
%       plotMesh(x)
%
%   Example 2:
%       % Create the mesh
%       x = mesh.Mesh(2,'TRI');
%       x.addNodes([0 0;1 0;0 1;1 1]);
%       x.addElems([1 2 3;2 4 3]);
%       % Plot it in black with + marker at nodes
%       plot(x,'k','Marker','+') 
%
%   See also Mesh, patch properties.

%   Copyright 2014 Pierre-Eric Allier (LMT) 

    % Check inputs
    narginchk(1,inf);
    start = 1;
    if ~isa(mesh, 'mesh.Mesh')
         error('ThermoPGD:plotMesh:BadInputs','Bad inputs arguments, check the doc.');
    end
    if (nargin == 1) || (mod(nargin-1,2) == 0)
        c = 'blue';
    else
        c = varargin{1};
        start = 2;
    end

    % Plot the mesh
    h = zeros(1,size(mesh.elems,1));
    for n = 1:size(mesh.elems,1)
        ids = mesh.elems(n,:);
        x = mesh.nodes(ids,1);
        if mesh.d > 1
            y = mesh.nodes(ids,2);
        else
            y = ones(size(x));
        end
        h(n) = patch(x,y,'w','EdgeColor',c,varargin{start:end});
    end

    if nargout == 1, hh = h; end
end