function data = loadGmshMesh(filename, elem_type)
%loadGmshMesh load a mesh from GMSH mesh file in format 1.0 or 2.0
%
%   mesh = loadGmshMesh(filename, elem_type) Load a GMSH file from is
%   filename and select only the element of type element_type since our
%   mesh object can only contain one kind of element. elem_type is a string
%   of value known by the Mesh object
%
%   Example:
%       x = loadGmshMesh('examples/3holles_2d_mesh.msh','TRI');
%       plotMesh(x)
%
%   see also Mesh.
%
%   Copyright 2014 Pierre-Eric Allier (LMT)

    gmsh_types = {'TRESS', ...
                  'TRI', ...
                  'QUAD'};

    fid = fopen( filename );
    if fid > 0
        % Header of files
        tline = fgetl(fid);
        if (strcmp(tline, '$NOD'))
            fileformat = 1;
        elseif (strcmp(tline, '$MeshFormat'))
            fileformat = 2;
            % Go to the $Nodes flag
            while ~strcmp(tline, '$Nodes') && ~feof(fid)
                tline = fgetl(fid);
            end
        else
            error('ThermoPGD:loadGmshMesh:BadFormat','Unknown mesh format.');
        end
        
        % Read the nodes coordinates
        if (strcmp(tline, '$NOD') || strcmp(tline, '$Nodes')) && ~feof(fid)
            nb_nodes = fscanf(fid, '%d', 1);
            coords = fscanf(fid, '%g', [4 nb_nodes]);
            fgetl(fid); % End previous line
            fgetl(fid); % Has to be $ENDNOD $EndNodes
        else
            error('ThermoPGD:loadGmshMesh:BadFile','Syntax error (no $NOD/$Nodes).');
        end
        coords = coords(2:end,:)'; % Remove the nodes ids
        
        tline = fgetl(fid);
        
        % Read the element connectivities
        if (strcmp(tline,'$ELM') || strcmp(tline, '$Elements')) && ~feof(fid)
            nb_elems = fscanf(fid, '%d', 1);
            fgetl(fid); % End previous line
            connec = [];
            for i=1:nb_elems
                tline = fgetl(fid);
                vals = sscanf(tline,'%d');
                if ~isempty(vals) && vals(2) <= length(gmsh_types) && vals(2) == find(ismember(gmsh_types,elem_type))
                    if fileformat == 1
                        connec = cat(2, connec, vals(6:end));
                    else % fileformat == 2
                        connec = cat(2, connec, vals((4+vals(3)):end));
                    end
                end
            end
        else
            error('ThermoPGD:loadGmshMesh:BadFile','Syntax error (no $Elements/$ELM).');
        end
        fgetl(fid); % Has to be $ENDELM or $EndElements
        fclose(fid);
        
        % Remove overdirection in coordinates nodes
        coords = coords(:,sum(coords,1) > eps);
        % Now create the mesh
        data = mesh.Mesh(size(coords,2),elem_type);
        ids = data.addNodes(coords);
        data.addElems(ids(connec'));
    else
        error('ThermoPGD:loadGmshMesh:BadFilename',['The file ' filename 'can''t be found']);
    end
end