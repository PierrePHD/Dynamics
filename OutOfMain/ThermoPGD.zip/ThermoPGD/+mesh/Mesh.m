%Mesh     A Mesh Representation for Finite Element Methods
%
%   Copyright 2014 Pierre-Eric Allier

classdef Mesh < handle
    properties (SetAccess = protected)
        d;                % Dimension of the mesh
        elem_type;        % Type of elements
        nodes = [];       % Coordinates table array of size [nb of nodes x d]
        elems = [];       % Connectivity table array of size [nb of elems x nb nodes per elems]
    end
    
    properties (Constant = true, Hidden = true)
        allowed_type = {'NODE','TRESS','TRI','QUAD'};
        nb_nodes_type = [1,2,3,4];
    end
    
    methods
        function obj = Mesh(dim, type)
        %Mesh constructor to define an empty finite element mesh.
        %
        %   obj = Mesh(dim, type) create a mesh of dimension dim of
        %   elements type type. The dimension dim can only take the value
        %   of 1 or 2 (1d or 2d) when the element type should be 'TRESS',
        %   'TRI' or 'QUAD'.
        %
        %   Example 1:
        %       % Create an empty 2D mesh of type 'TRI'
        %       Mesh(2, 'TRI');
        %
        %   Example 2:
        %       % Create an empty 2D mesh of type 'TRESS' even tress is a
        %       % 1D element type
        %       Mesh(2, 'TRESS');
        
            % Check the inputs
            if ~isnumeric(dim) || length(dim) ~= 1 || dim < 1 || dim > 3
                error('ThermoPGD:Mesh:BadMeshDimension','The dimension of the mesh should be 1 or 2.');
            end
            if ~ischar(type) || ~any(ismember(obj.allowed_type,upper(type)))
                error('ThermoPGD:Mesh:BadMeshType','Unknown type of elements. Should be ''TRESS'', ''TRI'', ''QUAD''.');
            end
            % Set them
            obj.d = dim;
            obj.elem_type = upper(type);
        end
        
        function ids = addNodes(obj,coors)
        %addNodes Add a list of nodes to a Mesh object
        %
        %   ids = addNodes(mesh, coors) add a nodes coordinate table to the 
        %   Mesh object mesh where coors is a [nb of nodes x dim] matrix, 
        %   dim > mesh.d and return a vector of the ids of the nodes in the
        %   mesh object.
        %
        %   Example:
        %       % Create the mesh
        %       x = mesh.Mesh(2,'TRI');
        %       x.addNodes([0 0;1 0;0 1;1 1]);
            
            if ~isnumeric(coors) && size(coors,2) < obj.d % Check inputs
                warning('ThermoPGD:Mesh:BadNodeDefinition','Nodes definition should be given as a numeric array.');
            else % Add them
                ids = size(obj.nodes,1)+1;
                obj.nodes = cat(1,obj.nodes,coors(:,1:obj.d));
                ids = (ids:size(obj.nodes,1))';
            end
        end
        
        function ids = addElems(obj,connecs)
        %addElems Add a list of elems to a Mesh object
        %
        %   ids = addElems(mesh, connecs) add a elems connectivity table to
        %   the  Mesh object mesh where connecs is a [nb of nodes x nb 
        %   nodes per elems] matrix, and return a vector of the ids of the 
        %   nodes in the mesh object.
        %
        %   Example:
        %       % Create the mesh
        %       x = mesh.Mesh(2,'TRI');
        %       x.addNodes([0 0;1 0;0 1;1 1]);
        %       x.addElems([1 2 3;2 4 3]);
        
            if ~isinteger(connecs) && ~obj.nb_nodes_type(ismember(obj.allowed_type,obj.elem_type)) == size(connecs,2)% Check inputs
                warning('ThermoPGD:Mesh:BadElemDefinition','Elems definition should be given as an integer array of nodes ids.');
            else % Add them
                ids = size(obj.elems,1)+1;
                obj.elems = cat(1,obj.elems,connecs);
                ids = (ids:size(obj.elems,1))';
            end
        end
        
        function table = edges(obj)
        %edges Return the edges in the mesh
        %
        %   table = edges(mesh) get the connectivity table of all edges in
        %   the Mesh object mesh.
        %
        %   Example:
        %       % Create the mesh
        %       x = mesh.Mesh(2,'TRI');
        %       x.addNodes([0 0;1 0;0 1;1 1]);
        %       x.addElems([1 2 3;2 4 3]);
        %       % Get the edges
        %       x.edges();
        
            table = [];
            % Create all edges from the element table of connectivity (we
            % are in 2D so we can)
            if ~strcmpi(obj.elem_type,'TRESS')
                for i=1:size(obj.elems,2)-1
                    table = cat(1,table,obj.elems(:,i:i+1));
                end
                table = cat(1,table,obj.elems(:,[end 1])); % Don't forget the last edge
            else
                table = (1:obj.nbNodes())';
            end
            % Remove the doublons
            [~,ids] = unique(sort(table,2),'rows');
            table = table(ids,:); % We do that in order to keep the orientation of boundaries
        end
        
        function data = freeBoundary(obj)
        %freeBoundary Return the sub-mesh facets formed by only one simplex
        %   
        %   submesh = freeBoundary(mesh) return a Mesh object containing 
        %   the facet elements of the mesh one.
        %
        %   Example:
        %       % Create the mesh
        %       x = mesh.Mesh(2,'TRI');
        %       x.addNodes([0 0;1 0;0 1;1 1]);
        %       x.addElems([1 2 3;2 4 3]);
        %       % Get the border of x
        %       x.freeBoundary();
        % 
            
            if obj.d > 1
                connec = [];
                % Create all edges from the element table of connectivity (we
                % are in 2D so we can)
                for i=1:size(obj.elems,2)-1
                    connec = cat(1,connec,obj.elems(:,i:i+1));
                end
                connec = cat(1,connec,obj.elems(:,[end 1])); % Don't forget the last edge
                
                % Remove those that appear twice
                [uniq_connec,~,ids] = unique(sort(connec,2),'rows','stable');
                ids = accumarray(ids,1); % Count the number of time the index appear
                connec = uniq_connec(ids == 1,:); % We do that in order to keep the orientation of boundaries
                
                % Create the mesh
                data = mesh.Mesh(obj.d, 'TRESS'); % It's only the first order in 1D/2D (simple)
                ids = data.addNodes(obj.nodes);
                data.addElems(ids(connec));
            else
                % Create the mesh
                data = mesh.Mesh(obj.d, 'NODE'); % It's only the first and last nodes
                data.addNodes(obj.nodes);
                data.addElems([find(obj.nodes == min(obj.nodes),1);find(obj.nodes == max(obj.nodes),1)]);
            end
        end
        
        function data = extract(obj, handle)
        %extract Extract a sub-mesh from the current mesh
        %
        %   submesh = extract(mesh, function_handle) from the current mesh 
        %   by finding the elements included in the sub-mesh area. This 
        %   area is defined as a fonction handle taking as arguments the 
        %   nodes coordinates which return true or false depending if the 
        %   node belong to the area wanted. Then the element are taken 
        %   depending if all their nodes belong to the sub-mesh.
        %
        %   Example:
        %       % Create the mesh
        %       x = mesh.Mesh(2,'TRI');
        %       x.addNodes([0 0;1 0;0 1;1 1]);
        %       x.addElems([1 2 3;2 4 3]);
        %       % Extract the submesh containg only the first element
        %       x.extract(@(x) x(1)+x(2) <= 1);
        
            % Check inputs
            if ~isa(handle,'function_handle')
                error('ThermoPGD:Mesh:BadExtractInput','The extract method take as input a handle function of x.');
            end
            
            % Extract
            is_nodes_in = cellfun(@(x) handle(x), num2cell(obj.nodes,2)); % Find the nodes that verify the function
            connec_ids = sum(is_nodes_in(obj.elems),2) == size(obj.elems,2); % Find the elements whose all nodes verify the function
            
            % Create the mesh
            data = mesh.Mesh(obj.d, obj.elem_type);
            data.addNodes(obj.nodes);
            data.addElems(obj.elems(connec_ids,:));
        end
        
        function submesh = extractElems(obj,ids)
        %extractElems extract a sub-mesh by keeping the element from their ids
        %
        %   submesh = extractElems(mesh,ids) where ids is an integer vector if
        %   multiple ids of element to keep in the sub-mesh
        %
        %   Example:
        %       % Create the mesh
        %       x = mesh.Mesh(2,'TRI');
        %       x.addNodes([0 0;1 0;0 1;1 1]);
        %       x.addElems([1 2 3;2 4 3]);
        %       % Get the edges
        %       x.extractElems(2);
        %
            if min(ids) < 1 && max(ids) > obj.nbElems()
                error('ThermoPGD:ErrorMesh:BadInput','Checl the doc for the extractElem function');
            end
            submesh = mesh.Mesh(obj.d,obj.elem_type);
            submesh.addNodes(obj.nodes);
            submesh.addElems(obj.elems(ids,:));
        end
        
        function n = nbNodes(obj)
        %nbNodes Return the number of the node of the mesh
            n = size(obj.nodes,1);
        end
        
        function n = nbElems(obj)
        %nbElems Return the number of elements of the mesh
            n = size(obj.elems,1);
        end
        
        function n = nbEdges(obj)
        %nbElems Return the number of elements of the mesh
            n = size(obj.edges,1);    
        end
    end
end