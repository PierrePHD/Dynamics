function hh = plotOnElems(mesh,values,varargin)
%plotOnElems Plots a vector of values at the Mesh nodes
%
%   plotOnElems(mesh, values) displays the elements contained in the Mesh 
%   object mesh with color according to the values vector.
%
%   H = plotOnElems(...) returns a vector of handles to the displayed 
%   elements.
%
%   plotOnNodes(...,'param','value','param','value'...) allows additional
%   line param/value pairs to be used when creating the plot.
%
%   Example:
%       % Create the mesh
%       x = mesh.Mesh(2,'TRI');
%       x.addNodes([0 0;1 0;0 1;1 1]);
%       x.addElems([1 2 3;2 4 3]);
%       f = [0 1];
%       % Plot it with
%       plotOnElems(x,f) 
%
%   See also Mesh, patch properties, plotMesh.
%
%   Copyright 2014 Pierre-Eric Allier (LMT)

    % Check inputs
    narginchk(2,inf);
    if ~isa(mesh, 'mesh.Mesh') || ~isnumeric(values) || mod(size(values,1),size(mesh.elems,1)) ~= 0
         error('ThermoPGD:plotOnElems:BadInputs','Bad inputs arguments, check the doc.'); 
    end
    
    q = length(values)/size(mesh.elems,1); % The number of value on each element (integer since we check it)
    
    % Plot the mesh
    if mesh.d == 1
        % Compute the mean of values
        mean_vals = zeros(size(mesh.elems,1),size(values,2));
        for i=1:size(values,2)
            mean_vals(:,i) = mean(reshape(values(:,i),q,[]),1)';
        end
        % plot it
        h = stairs(mesh.nodes(:),[mean_vals;mean_vals(end,:)]);
    else
        h = zeros(1,size(mesh.elems,1));
        for n = 1:size(mesh.elems,1)
            ids = mesh.elems(n,:);
            x = mesh.nodes(ids,1);
            y = mesh.nodes(ids,2);
            c = mean(values((n-1)*q+1:n*q,1))*ones(size(x));
            h(n) = patch(x,y,c,'FaceColor','interp',varargin{3:end});
        end
        % Add a button for a user selection of data
        if size(values,2) > 1
            set(gcf,'ResizeFcn',{@resizeFunc,gca});
            legend = regexprep(num2str(1:size(values,2),'%d|'),'[^\w|'']','');
            select = uicontrol(gcf,'Style','popup','String', legend(1:end-1), ...
                      'Callback',@redraw);
            parent_varargin = varargin;
            fig = gca;
        end
    end

    if nargout == 1, hh = h; end
    
    % Nested Functions for user selection
    function resizeFunc(varargin)
        axes_pos = get(varargin{3},'OuterPosition');
        fig_pos = get(varargin{1},'position');
        set(select,'Position',[fig_pos(3)*axes_pos(1) fig_pos(4)*(axes_pos(2)+axes_pos(4))-50 65 50]);
    end

    function redraw(varargin)
        data_id = get(varargin{1},'Value');
        keyboard
        for n = 1:size(mesh.elems,1)
            ids = mesh.elems(n,:);
            x = mesh.nodes(ids,1);
            y = mesh.nodes(ids,2);
            c = mean(values((n-1)*q+1:n*q,data_id))*ones(size(x));
            patch(x,y,c,'FaceColor','interp',parent_varargin{3:end},'Parent',fig);
        end
        caxis(fig,[min(values(:,data_id)) max(values(:,data_id))]);
    end
end