function data = segmentMesh(list)
%segmentMesh Create a 1D mesh based on the vector of coordinates
%
%   mesh = segmentMesh(list) create a 1D mesh based on the vector of 
%   coordinates list of length the number of nodes
%
%   Example:
%       x = segmentMesh(1:10);
%       plotMesh(x)
%
%   see also Mesh.
%
%   Copyright 2014 Pierre-Eric Allier (LMT)

    % Checing inputs
    if ~isvector(list) || ~isnumeric(list)
        error('');
    end
    list = list(:); % Just to be sure
    
    data = mesh.Mesh(1,'TRESS');
    data.addNodes(list);
    data.addElems([1:data.nbNodes()-1;2:data.nbNodes()]');
end