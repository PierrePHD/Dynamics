function sigma = femDualField(u, k)
%femDualField Compute the Dual field of the FEM solution 
%
%   phi = femDualField(u, k) compute the dual field of the FEM solution u 
%   computed on the mesh x with the Thermic problem defined by c,k,ud,fd,rd,Fd
%
    % Check inputs
    if ~isa(u,'fem.FEMSol')
        error('ThermoPGD:femDualField:BadInput','Bad inputs, check the doc');
    end
    x = u.meshes;
    
    disp('[-]FEM DUAL FIELD EVALUATION');
    
    % Compute a combination array of extra coordinates
    dims = cellfun(@(x) x.nbNodes(),x,'UniformOutput',false);
    if length(dims) == 1 
        id_params = cell(1);
    elseif length(dims) == 2
        id_params = num2cell(1:dims{2})';
    else
        id_params = cell(dims{2:end});
        for i=1:length(id_params(:))
            id_params{i} = ind(size(id_params),i);
        end
    end
    
    K = cell(size(k));
    for i=1:size(k,2)
        K{1,i} = formulation.FEMGrad(x{1},k{1,i});
        if length(x) > 1
            K(2:end,i) = cellfun(@(x,k) mesh.evalOnMesh(x,k),x(2:end),k(2:end,i),'UniformOutput',false);
        end
    end
    % Compute the admissible field (in the FEM sense)
    S = cellfun(@(ids) grad(K,u,ids),id_params,'UniformOutput',false);
    
    % Reshape the solution
    sigma = fem.FEMSol(x);
    sigma.setRepresentation({'Elems'});
    if length(x) > 1
        sigma.setData(reshape(cell2mat(S(:)'),[length(S{1}) dims{2:end}])); % Turn S into a full solution
    else
        sigma.setData(S{1});
    end
end

function s = grad(K,u,ids)
    s = 0;
    ids = num2cell(ids);
    for i=1:size(K,2)
        se = 1;
        for j=2:size(K,1)
            se = se*K{j,i}(ids{j-1});
        end
        s = s + se*K{1,i}*u.fullRep({[] ids{:}});
    end
    
end

function id = ind(siz,ndx)
%IND Multiple subscripts from linear index.
%   IND is used to determine the equivalent subscript values
%   corresponding to a given single index into an array.
%
    m = length(siz);
    id = zeros(m,1);
    k = [1 cumprod(siz(1:end-1))];

    for i=m:-1:1
        vi = rem(ndx-1, k(i)) + 1;         
        vj = (ndx - vi)/k(i) + 1; 
        id(i) = vj; 
        ndx = vi;     
    end
end