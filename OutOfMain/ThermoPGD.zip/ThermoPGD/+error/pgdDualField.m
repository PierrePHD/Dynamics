function sigma = pgdDualField(u, c, k, ud, fd, rd, Fd, no_time)
%pgdDualField Compute the Dual field of the PGD solution 
%
%   phi = pgdDualField(u, c, k, ud, fd, rd, Fd) compute the dual field
%   of the PGD solution u computed on the mesh x with the Thermic problem
%   defined by c,k,ud,fd,rd,Fd
%
    if nargin == 7
        no_time = false;
    end

    disp('[-]PGD DUAL FIELD EVALUATION');
    
    x = u.meshes;
    d = length(x); % PGD dimension
    
    sigma = error.PGDDualSol(u.meshes); % The flux
    if no_time
        sigma.setRepresentation({'Elems'});
    else
        sigma.setRepresentation({'Elems','Elems'});
    end
    
    % Mask computation
    mask = cell(d,1);
    for j=1:d
        mask{j} = logical(mesh.evalOnMesh(x{j},ud{j,1}));
    end
    
    disp('   -> Compute the static flux field');
    %% Compute the flux from the Neumann conditions
    A = formulation.FEMMat(x{1},1,1,k{1,1});
    for j=2:size(k,2)
        A = A + formulation.FEMMat(x{1},1,1,k{1,j});
    end
    
    for i=1:size(fd,2)
        F = formulation.FEMVec(x{1},0,fd{1,i});
        v = ones(x{1}.nbNodes(),1);
        v(mask{1}) = 0;
        v(~mask{1}) = A(~mask{1},~mask{1})\F(~mask{1});
        
        data = cellfun(@mesh.evalOnMesh,x(2:end),fd(2:end,i),'UniformOutput',false);
        sigma.addStaticMode({formulation.FEMGrad(x{1},v), data{:}});
    end
    for i=1:size(rd,2)
        F = formulation.FEMVec(x{1}.freeBoundary(),0,rd{1,i});
        v = ones(x{1}.nbNodes(),1);
        v(mask{1}) = 0;
        v(~mask{1}) = A(~mask{1},~mask{1})\F(~mask{1});
        
        data = cellfun(@mesh.evalOnMesh,x(2:end),rd(2:end,i),'UniformOutput',false);
        sigma.addStaticMode({formulation.FEMGrad(x{1},v), data{:}});
    end
    for i=1:size(Fd,2)
        F = formulation.FEMVec(x{1}.freeBoundary().freeBoundary(),0,Fd{1,i});
        v = ones(x{1}.nbNodes(),1);
        v(mask{1}) = 0;
        v(~mask{1}) = A(~mask{1},~mask{1})\F(~mask{1});
        
        data = cellfun(@mesh.evalOnMesh,x(2:end),Fd(2:end,i),'UniformOutput',false);
        sigma.addStaticMode({formulation.FEMGrad(x{1},v), data{:}});
    end
    
    disp('   -> Compute the PGD flux field');
    %% Compute the flux from the PGD solution
    % Some usefull matrix
    if ~no_time
        sigma = equilibriumDisplacement(x,u,sigma,c,k);
    else
        sigma = minimizationCRError(x,u,sigma,k);
    end
    
    keyboard
end

function sigma = equilibriumDisplacement(x,u,sigma,c,k)
%equilibriumDisplacement compute an Dual field of u that is admissible in
%the FEM sense. It based on the displacement of equilibrium

    d = length(x); % PGD dimension
    m = u.nbModes(); % The number of PGD modes
    
    % Compute usefull matrix
    K = cell(d,size(c,2)+size(k,2));
    for i=1:size(c,2)
        for j=1:d
            if j == 2
                K{j,i} = formulation.FEMMat(x{j},1,0,c{j,i});
            else
                K{j,i} = formulation.FEMMat(x{j},0,0,c{j,i});
            end
        end
    end
    n_tmp = size(c,2);
    for i=1:size(k,2)
        for j=1:d
            if j == 1
                K{j,n_tmp+i} = formulation.FEMMat(x{j},1,1,k{j,i});
            else
                K{j,n_tmp+i} = formulation.FEMMat(x{j},0,0,k{j,i});
            end
        end
    end
    
    M = cell(d,1);
    for j=1:d
        if j ~= 1
            M{j,1} = formulation.FEMMat(x{j},0,0,@(x) 1);
        end
    end
        
    nb_ddl_sigma = length(formulation.FEMGrad(x{1},u.data{1}(:,1)));
    
    % Compute the FEM equilibrate field
    Q = zeros(nb_ddl_sigma,m);
    for i=1:m
        for j=1:sigma.nbStaticModes()
            alpha = 1;
            s_d = sigma.getStaticModes(j);
            for p=2:d
                alpha = alpha*u.data{p}(:,i)'*M{p,1}*s_d.data{p};
            end
            Q(:,i) = Q(:,i) - alpha*s_d.data{1};
        end
        for j=1:i
            for l=1:size(k,2)
                alpha = 1;
                for p=2:d
                    alpha = alpha*u.data{p}(:,i)'*K{p,n_tmp+l}*u.data{p}(:,j);
                end
                Q(:,i) = Q(:,i) + alpha*formulation.FEMGrad(x{1},u.data{1}(:,j),k{1,l});
            end
        end
    end
    
    % inversion of the prolongement condition
    R = zeros(m,m);
    for i=1:m
        for j=1:i
            for l=1:size(c,2)
                alpha = 1;
                for p=2:d
                    alpha = alpha*u.data{p}(:,i)'*K{p,l}*u.data{p}(:,j);
                end
                R(i,j) = R(i,j) + mean(mesh.evalOnMesh(x{1},c{1,l}))*alpha;
            end
        end
    end
     
    data = (R\Q')';
    
    disp(['Q = ' num2str(norm(Q)) ' ; R_mm = ' num2str(min(diag(R)))]);
        
    % Verify if the equilibrium is still respected
    L = x{1}.nodes(end,1);
    v = mesh.evalOnMesh(x{1},@(y) y.*(L-y));       
    cKx = formulation.FEMMat(x{1},1,1,@(x) 1,'gauss2nodes');
    Mx = formulation.FEMMat(x{1},0,0,@(x) 1);
    disp(['initial equilibrium : ' num2str((v'*cKx'*Q + v'*Mx*(R*u.data{1}')')./(v'*cKx'*Q))]);
    disp(['final quilibrium : ' num2str((v'*cKx'*data + v'*Mx*u.data{1})./(v'*cKx'*Q))]);

    
    for i=1:m
        vals = cell(d,1);
        for j=1:d
            if j == 1
                vals{j} = mean(mesh.evalOnMesh(x{j},c{j,1})).*data(:,i);
            elseif j == 2
                vals{j} = mean(mesh.evalOnMesh(x{j},c{j,1})).*formulation.FEMGrad(x{j},u.data{j}(:,i));
            else
                vals{j} = mean(mesh.evalOnMesh(x{j},c{j,1})).*u.data{j}(:,i);
            end
        end
        sigma.addMode(vals(:));
    end
end

function sigma = minimizationCRError(x,u,sigma,k)
%minimizationCRError compute an Dual field of u that is admissible in
%the FEM sense by minimizing the Constitutive Relation Error.
    m_max = u.nbModes();
    k_max = 10;
    
    d = length(x); % PGD dimension
    
    % Compute usefull matrix
    M = cell(d,size(k,2));
    K = cell(d,1);
    for j=1:d
        for i=1:size(k,2)
            if j == 1
                M{1,i} = formulation.FEMMat(x{1},0,0,@(x) safeInv(double(k{1,i}(x))),'gauss2gauss');
            else
                M{j,i} = formulation.FEMMat(x{j},0,0,@(x) 1./k{j,i}(x));
            end
        end
        if j == 1
            K{1,1} = formulation.FEMMat(x{j},0,1,@(y) ones(x{1}.d,1),'gauss2nodes');
        else
            K{j,1} = formulation.FEMMat(x{j},0,0,@(x) 1);
        end
    end
    
    beta = cell(m_max,d); % The functions of sigma (unknown)
    
    % Initialization
    for i=1:m_max
        beta{i,1} = formulation.FEMGrad(x{1},u.data{1}(:,i));
        beta(i,2:end) = cellfun(@(x) mean(x.nodes)*ones(x.nbNodes(),1),x(2:end),'UniformOutput',false);
    end
    
    % Fixed point algorithm
    for k=1:k_max*m_max
        for m=1:m_max
            for l=2:d
                % Compute the bilinear matrix
                B = 0;
                for j=1:size(M,2)
                    Be = 1;
                    for o=setdiff(1:d,l)
                        Be = Be*beta{m,o}'*M{o,j}*beta{m,o};
                    end
                    B = B + Be*M{l,j};
                end
                % Compute the linear vector
                F = 0;
                for i=1:m_max
                    if i ~= m
                        for j=1:size(M,2)
                            Fe = 1;
                            for o=setdiff(1:d,l)
                                Fe = Fe*beta{m,o}'*M{o,j}*beta{i,o};
                            end
                            F = F + Fe*M{l,j}*beta{i,l};
                        end
                    end
                    for j=1:size(K,2)
                        Fe = 1;
                        for o=setdiff(1:d,l)
                            Fe = Fe*beta{m,o}'*K{o,j}*u.data{o}(:,i);
                        end
                        F = F - Fe*K{l,j}*u.data{l}(:,i);
                    end
                end
                for i=1:sigma.nbStaticModes()
                    for j=1:size(M,2)
                        Fe = 1;
                        s_d = sigma.getStaticModes(i);
                        for o=setdiff(1:d,l)
                            Fe = Fe*beta{m,o}'*M{o,j}*s_d.data{o}(:,i);
                        end
                        F = F + Fe*M{l,j}*s_d.data{l}(:,i);
                    end
                end
                
                beta{m,l} = B\F;
                % Norm them except the last one for stability purpose %TODO
%                 if l ~= d
%                     beta{m,l} = beta{m,l}/norm(beta{m,l});
%                 end
            end
        end
    end
    
    % Store it on a PGD form
    for i=1:m_max
        sigma.addMode(beta(i,:));
    end
end

function res = safeInv(matrix)
    if all(matrix <= eps)
        res = zeros(size(matrix));
    else
        res = inv(matrix);
    end
end