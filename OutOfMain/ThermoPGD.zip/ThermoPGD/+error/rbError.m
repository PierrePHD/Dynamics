function err = rbError(x, u, c, k, ud, fd, rd, Fd)
    disp('[-]ERROR EVALUATION');
    d = length(x); % PGD dimension
    n = size(fd,2)+size(rd,2)+size(Fd,2); % The number of Neumann conditions
    m = u.nbModes(); % The number of PGD modes
    
    nb_ddl_sigma = length(formulation.FEMGrad(x{1},u.data{1}(:,1)));
    
    sigma_d = pgd.PGDRep(d); % The CL flux
    sigma = pgd.PGDRep(d); % The PGD flux
    
    % Mask computation
    mask = cell(d,1);
    for j=1:d
        mask{j} = logical(mesh.evalOnMesh(x{j},ud{j,1}));
    end
    
    disp('   -> Compute the flux field');
    %% Compute the flux from the Neumann conditions
    A = formulation.FEMMat(x{1},1,1,k{1,1});
    for j=2:size(k,2)
        A = A + formulation.FEMMat(x{1},1,1,k{1,j});
    end
    
    for i=1:size(fd,2)
        F = formulation.FEMVec(x{1},0,fd{1,i});
        v = ones(x{1}.nbNodes(),1);
        v(mask{1}) = 0;
        v(~mask{1}) = A(~mask{1},~mask{1})\F(~mask{1});
        
        data = cellfun(@mesh.evalOnMesh,x(2:end),fd(2:end,i),'UniformOutput',false);
        sigma_d.addMode(formulation.FEMGrad(x{1},v), data{:});
    end
    for i=1:size(rd,2)
        F = formulation.FEMVec(x{1},0,rd{1,i});
        v = ones(x{1}.nbNodes(),1);
        v(mask{1}) = 0;
        v(~mask{1}) = A(~mask{1},~mask{1})\F(~mask{1});
        
        data = cellfun(@mesh.evalOnMesh,x(2:end),rd(2:end,i),'UniformOutput',false);
        sigma_d.addMode(formulation.FEMGrad(x{1},v), data{:});
    end
    for i=1:size(Fd,2)
        F = formulation.FEMVec(x{1},0,Fd{1,i});
        v = ones(x{1}.nbNodes(),1);
        v(mask{1}) = 0;
        v(~mask{1}) = A(~mask{1},~mask{1})\F(~mask{1});
        
        data = cellfun(@mesh.evalOnMesh,x(2:end),Fd(2:end,i),'UniformOutput',false);
        sigma_d.addMode(formulation.FEMGrad(x{1},v), data{:});
    end
    
    %% Compute the flux from the PGD solution
    % Some usefull matrix
    M = cell(d,1);
    for j=1:d
        if j == 1
            M{j,1} = formulation.FEMMat(x{j},0,1,@(x) [1;1]);
        else
            M{j,1} = formulation.FEMMat(x{j},0,0,@(x) 1);
        end
    end
    
    K = cell(d,size(c,2)+size(k,2));
    for i=1:n
        for j=1:d
            if j == 2
                K{j,i} = formulation.FEMMat(x{j},1,0,c{j,i});
            else
                K{j,i} = formulation.FEMMat(x{j},0,0,c{j,i});
            end
        end
    end
    n_tmp = size(c,2);
    for i=1:size(k,2)
        for j=1:d
            if j == 1
                K{j,n_tmp+i} = formulation.FEMMat(x{j},1,1,k{j,i});
            else
                K{j,n_tmp+i} = formulation.FEMMat(x{j},0,0,k{j,i});
            end
        end
    end
    
    % Compute the FEM equilibrate field
    Q = zeros(nb_ddl_sigma,m);
    for i=1:m
        for j=1:n
            alpha = 1;
            for p=2:d
                alpha = alpha*u.data{p}(:,i)'*K{p,1}*sigma_d.data{p}(:,j);
            end
            Q(:,i) = Q(:,i) - alpha*sigma_d.data{1}(:,j);
        end
        for j=1:i
            for l=1:size(k,2)
                alpha = 1;
                for p=2:d
                    alpha = alpha*u.data{p}(:,i)'*K{p,n_tmp+l}*u.data{p}(:,j);
                end
                Q(:,i) = Q(:,i) + alpha*formulation.FEMGrad(x{1},u.data{1}(:,j));
            end
        end
    end
    
    % inversion of the prolongement condition
    R = zeros(m,m);
    for i=1:m
        for j=1:i
            for l=1:size(c,2)
                alpha = 1;
                for p=2:d
                    alpha = alpha*u.data{p}(:,i)'*K{p,l}*u.data{p}(:,j);
                end
                R(i,j) = R(i,j) - alpha;
            end
        end
    end
     
    data = (R\Q')';
    for i=1:m
        vals = cell(d,1);
        for j=1:d
            if j == 1
                vals{j} = mean(mesh.evalOnMesh(x{j},c{j,1})).*data(:,i);
            elseif j == 2
                vals{j} = -mean(mesh.evalOnMesh(x{j},c{j,1})).*formulation.FEMGrad(x{j},u.data{j}(:,i));
            else
                vals{j} = mean(mesh.evalOnMesh(x{j},c{j,1})).*u.data{j}(:,i);
            end
        end
        sigma.addMode(vals{:});
    end
    
    %% Compute the Admissible field
    disp('   -> Compute the admissible field');
    
    %% Error Evaluation
    disp('   -> Compute the error');
    % Compute the Matrix
    Ad = cell(d,size(k,2));
    A = cell(2,size(k,2));
    for i=1:size(k,2)
        Ad{1,i} = formulation.FEMMat(x{1},0,0,@(x) iif(k{1,i}(x) == 0,0,1./k{1,i}(x)),'elementary','gauss2gauss');
        Ad{2,i} = formulation.FEMMat(x{2},0,0,@(x) 1./k{2,i}(x),'elementary');
        for j=3:d
            Ad{j,i} = formulation.FEMMat(x{j},0,0,@(x) 1./k{j,i}(x),'elementary');
        end
        A{1,i} = formulation.FEMMat(x{2},0,0,@(x) 1./k{2,i}(x),'elementary','gauss2nodes');
        A{2,i} = formulation.FEMMat(x{2},0,0,@(x) 1./k{2,i}(x),'elementary','gauss2gauss');
    end
    
    B = cell(d,size(k,2));
    for i=1:size(k,2)
        B{1,i} = formulation.FEMMat(x{1},1,1,k{1,i},'elementary');
        B{2,i} = formulation.FEMMat(x{2},0,0,k{2,i},'elementary');
        for j=3:d
            B{j,i} = formulation.FEMMat(x{j},0,0,k{j,i},'elementary');
        end
    end
    
    Cd = cell(d,1);
    C = cell(1,1);
    Cd{1,1} = formulation.FEMMat(x{1},0,1,@(x) [1;1],'elementary','gauss2nodes');
    Cd{2,1} = formulation.FEMMat(x{2},0,0,@(x) 1,'elementary');
    for j=3:d
        Cd{j,1} = formulation.FEMMat(x{j},0,0,@(x) 1,'elementary');
    end
    C{1,l} = formulation.FEMMat(x{2},0,0,@(x) 1,'elementary','gauss2nodes');
    
    err = 0;
    for l=1:size(k,2)
        for i=1:n
            for j=1:n
            	err = err + evalError(sigma_d.getModes(i),Ad(:,l),sigma_d.getModes(j));
            end
            for j=1:m
                err = err + 2*evalError(sigma.getModes(j),{Ad{1,l} A{1,l} Ad{3:end,l}},sigma_d.getModes(i));
            end
        end
        for i=1:m
            for j=1:m
                err = err + evalError(sigma.getModes(i),{Ad{1,l} A{2,l} Ad{3:end,l}},sigma.getModes(j));
                err = err + evalError(u.getModes(i),B(:,l),u.getModes(j));
                
            end
        end
    end
    for i=1:n
        for j=1:m
            err = err + 4*evalError(sigma_d.getModes(i),Cd(:,1),u.getModes(j));
        end
        for j=1:m
            err = err + 2*evalError(sigma.getModes(i),{Cd{1,1} C{1,1} Cd{3:end,1}},u.getModes(j));
        end
    end
    
end

function val = iif(expr, truepart, falsepart)
    if isscalar(truepart)
        truepart=truepart(ones(size(expr)));
    end
    if isscalar(falsepart)
       falsepart=falsepart(ones(size(expr))); 
    end
    val = arrayfun(@iif_scalar, expr, truepart, falsepart);
end
function val = iif_scalar(expr,truepart,falsepart)
    if expr
        val = truepart;
    else
        val = falsepart;
    end
end

function items = evalError(u,K,v)
    n = length(u.data);
    data = cell(n,1);
    for i=1:n
        data{i} = cellfun(@(k) u.data{i}'*k*v.data{i},K{i});
    end
    items = pgd.outProd(data{:});
end