classdef PGDDualSol < pgd.PGDSol
%PGDDualSol A class to represente any kind of PGD dual solution discretized on a
%high dimensional space

    properties
        static_data; % data structure to hold the static field
    end
    
    methods
        function obj = PGDDualSol(meshes)
        %PGDDualSol constructor (see the PGDDualSol constructor help)  
            obj = obj@pgd.PGDSol(meshes);
            
            obj.static_data = cell(length(meshes),1);
        end
        
        function m = nbStaticModes(obj)
        %nbStaticModes Return the number of PGD modes in the static part of this representation
            m = size(obj.static_data{1},2); % There is at least one meshes from the check in FEMSol
        end
        
        
        function obj = setStaticMode(obj,data,i)
        %setStaticMode set a PGD mode to the static part of the current object.
        %
        %    setSataticMode(obj,{fct1,fct2,...fctd},i) where d is the dimension of the PGD
        %    space and fct, fonctions of each dimension and i the index of
        %    the mode to change. If you want to add a mode, see the addStaticMode
        %    function.
        %
            if iscell(data) && i <= obj.nbStaticModes() && length(data) == length(obj.meshes)
                for j=1:length(data)
                    obj.static_data{j}(:,i) = data{j}(:);
                end
            else
                error('ThermoPGD:PGDDualSol:BadInput','Bad input in the setStaticMode function. Check the doc.');
            end
        end
        
        function obj = addStaticMode(obj,data)
        %addStaticMode Add a PGD mode to the static part of the current object.
        %
        %    addStaticMode(obj,{fct1,fct2,...fctd}) where d is the dimension of the PGD
        %    space and fct, fonctions of each dimension.
        %
            if iscell(data) && length(data) == length(obj.meshes)
                obj.static_data = cellfun(@(data,x) [data x(:)],obj.static_data,data(:),'UniformOutput',false);
            else
                error('ThermoPGD:PGDDualSol:BadInput','Bad input in the addMode function. Check the doc.');
            end
        end
        
        function mode = getStaticModes(obj,i)
        %getStaticModes Return only the ith modes as a PGDRep object
        %
        %    vals = getStaticModes(obj, i) where i is an integer or list of integer
        %    lower or equal than the number of PGD modes in this representation
        %
            if all(abs(i - round(i)) < eps) && max(i) <= obj.nbStaticModes() && min(i) > 0
                rep = obj.kind_of_rep;
                if length(rep) >= 2
                    % If it's time dependent ok, otherwise it's a parameter
                    % and it's at the nodes also (or should be)
                    rep{2} = 'Nodes';
                end
                mode = pgd.PGDSol(obj.meshes);
                mode.setRepresentation(rep);
                vals = cellfun(@(x) x(:,i),obj.static_data,'UniformOutput',false);
                mode.data = vals;
            else
                error('ThermoPGD:PGDDualSol:BadInput','Bad input in the getModes function. Check the doc.');
            end    
        end
        
        function n = nbModes(obj)
            n = size(obj.static_data{1},2) + size(obj.data{1},2);
        end
        
        function mode = getModes(obj,i)
            if all(abs(i - round(i)) < eps) && max(i) <= obj.nbModes() && min(i) > 0
                mode = error.PGDDualSol(obj.meshes);
                mode.setRepresentation(obj.kind_of_rep);
                
                static_id = i(i <= obj.nbStaticModes());
                vals = cellfun(@(x) x(:,static_id),obj.static_data,'UniformOutput',false);
                mode.static_data = vals;
                pgd_id = i(i > obj.nbStaticModes()) - obj.nbStaticModes();
                vals = cellfun(@(x) x(:,pgd_id),obj.data,'UniformOutput',false);
                mode.data = vals;
            else
                error('ThermoPGD:PGDDualSol:BadInput','Bad input in the getModes function. Check the doc.');
            end   
        end
        
        function n = nbPGDModes(obj)
            n = size(obj.data{1},2);
        end
        
        function mode = getPGDModes(obj,i)
            if all(abs(i - round(i)) < eps) && max(i) <= obj.nbPGDModes() && min(i) > 0
                mode = pgd.PGDSol(obj.meshes);
                mode.setRepresentation(obj.kind_of_rep);
                vals = cellfun(@(x) x(:,i),obj.data,'UniformOutput',false);
                mode.data = vals;
            else
                error('ThermoPGD:PGDDualSol:BadInput','Bad input in the getPGDModes function. Check the doc.');
            end  
        end
        
        function vals = fullRep(obj,ids)
        % Return the full representation of the solution over the whole space
        %
        %   fullRep(obj) return the full representation.
        %   
        %   fullRep(obj, ids) return the full tensor of the
        %   representation where ids are a cell of same size than the
        %   representation one of value to eval the output. Usefull for
        %   computing only the dependency of one parameter where the other
        %   are fixed to a certain value.
        %
        %   Example :
        %       a.fullRep({[],2})
            if nargin <= 1
                ids = cell(obj.dim(),1);
            elseif length(ids) ~= obj.dim()
                error('ThermoPGD:PGDRep:BadInput','Bad input in the fullRep function. Check the doc.');
            end
            
            % Then we need to set (:) for the empty index return
            for i=1:obj.dim()
                if isempty(ids{i})
                    ids{i} = 1:size(obj.data{i},1);
                end
            end
            ids = ids(:);
            
            % Compute the grad of time function if requested
            if strcmpi(obj.kind_of_rep{2},'Elems')
                tmp_time_vals = formulation.FEMGrad(obj.meshes{2},obj.static_data{2},@(x) 1);
            else
                tmp_time_vals = obj.static_data{2};
            end
            
            % Compute the tensor representation of the static part
            if size(obj.static_data{1},2) > 0
                data = {obj.static_data{1} tmp_time_vals obj.static_data{3:end}}';
                extract = cellfun(@(x,id) x(id,1),data,ids,'UniformOutput',false);
                static_vals = pgd.outProd(extract{:});
                for i=2:size(obj.static_data{1},2)
                    extract = cellfun(@(x,id) x(id,i),data,ids,'UniformOutput',false);
                    static_vals = static_vals + pgd.outProd(extract{:});
                end
            else
                static_vals = 0;
            end

            % Compute the tensor representation of the PGD part 
            if size(obj.data{1},2) > 0
                extract = cellfun(@(x,id) x(id,1),obj.data,ids,'UniformOutput',false);
                vals = pgd.outProd(extract{:});
                for i=2:size(obj.data{1},2)
                    extract = cellfun(@(x,id) x(id,i),obj.data,ids,'UniformOutput',false);
                    vals = vals + pgd.outProd(extract{:});
                end
            else
                vals = 0;
            end
            
            % Add  them
            vals = vals + static_vals;
        end
        
        function obj = setData(obj,data)
        % Allow to set the value of the solution
            
            dims = cellfun(@(x,rep) strcmpi(rep,'Nodes')*x.nbNodes()+strcmpi(rep,'Elems')*x.nbElems(),obj.meshes,obj.kind_of_rep);
            correct_dims = size(data);
            if length(dims) == length(correct_dims) && all(dims == correct_dims) % Check size
                obj.data = data;
            else
                error('ThermoPGD:FEMSol:BadInputDim','In setData, the input should have the correct size.');
            end
        end
    end
    
end