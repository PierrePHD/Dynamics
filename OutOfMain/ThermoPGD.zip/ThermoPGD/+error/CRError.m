function [err,norm_err] = CRError(u,s,k, no_time)
% Evaluate the Constitutive relation error (s - k*grad(u))
%
    % Input check
    if ~isa(u,'pgd.PGDSol') && ~isa(s,'error.PGDDualSol') && ~iscell(k)
        error('ThermoPGD:CRError:BadInput','Bad inputs in CRError function. Check the doc.');
    end
    
    % Initialization
    if nargin == 3
        no_time = false;
    end
    if strcmpi(s.kind_of_rep{1},'Elems')
        is_admissible = true;
    else
        is_admissible = false;
    end
    
    x = u.meshes;
    d = length(x);
    m_max = u.nbModes();
    
    disp('[-]CR ERROR EVALUATION');
    
    % Compute the Matrix
    A = cell(d+2,size(k,2));
    for i=1:size(k,2)
        if is_admissible
            A{1,i} = formulation.FEMMat(x{1},0,0,@(x) safeInv(double(k{1,i}(x))),'elementary','gauss2gauss');
        else
            A{1,i} = formulation.FEMMat(x{1},0,0,@(x) safeInv(double(k{1,i}(x))),'elementary');
        end
        if ~no_time
            A{2,i} = formulation.FEMMat(x{2},0,0,@(x) 1./k{2,i}(x),'elementary');
            A{d+1,i} = formulation.FEMMat(x{2},0,0,@(x) 1./k{2,i}(x),'elementary','gauss2nodes');
            A{d+2,i} = formulation.FEMMat(x{2},0,0,@(x) 1./k{2,i}(x),'elementary','gauss2gauss');
        end
        for j=(3*~no_time + 2*no_time):d
            A{j,i} = mesh.evalOnMesh(x{j},@(x) 1./k{j,i}(x));
        end
    end
    
    B = cell(d,size(k,2));
    for i=1:size(k,2)
        B{1,i} = formulation.FEMMat(x{1},1,1,k{1,i},'elementary');
        if ~no_time  
            B{2,i} = formulation.FEMMat(x{2},0,0,k{2,i},'elementary');
        end
        for j=(3*~no_time + 2*no_time):d
            B{j,i} = mesh.evalOnMesh(x{j},k{j,i});
        end
    end
    
    C = cell(d+1,1);
    if is_admissible
        C{1,1} = formulation.FEMMat(x{1},0,1,@(y) ones(x{1}.d,1),'elementary','gauss2nodes');
    else
        C{1,1} = formulation.FEMMat(x{1},0,1,@(y) ones(x{1}.d,1),'elementary');
    end
    if ~no_time
        C{2,1} = formulation.FEMMat(x{2},0,0,@(x) 1,'elementary');
        C{d+1,1} = formulation.FEMMat(x{2},0,0,@(x) 1,'elementary','gauss2nodes');
    end
    for j=(3*~no_time + 2*no_time):d
        C{j,1} = 1;
    end

    % Evaluate the error
    err = cell(m_max+1,1);
    norm_err = cell(m_max+1,1);
    % Compute the int(s_d*k^-1*s_d) (the error without PGD modes)
    disp('   -> Initial error evaluation');
    err{1} = 0;
    for l=1:size(k,2)
        for i=1:s.nbStaticModes()
            for j=1:s.nbStaticModes()
                err{1} = err{1} + evalError(s.getStaticModes(i),A(1:d,l),s.getStaticModes(j));
            end
        end
    end
    norm_err{1} = err{1};
    
    % Compute the mode error where s_m = s_d + s_{m-1} + s and u_m = u_{m-1} + u
    for m=1:m_max
        disp('   -> New error mode evaluation');
        err_mode = 0;
        for l=1:size(k,2) % loop over the k PGD sum
            % Compute the 2*int(s_d*k^-1*s)
            for i=1:s.nbStaticModes()
                if ~no_time
                    err_mode = err_mode + 2*evalError(s.getPGDModes(m),A([1 d+1 3:d],l),s.getStaticModes(i));
                else
                    err_mode = err_mode + 2*evalError(s.getPGDModes(m),A(:,l),s.getStaticModes(i));
                end
            end
            % Compute the 2*int(s_{m-1}*k^-1*s) + 2*int(grad(u_{m-1})*k*grad(u))
            for i=1:m-1
                if ~no_time
                    err_mode = err_mode + 2*evalError(s.getPGDModes(m),A([1 d+2 3:d],l),s.getPGDModes(i));
                else
                    err_mode = err_mode + 2*evalError(s.getPGDModes(m),A(:,l),s.getPGDModes(i));
                end
                err_mode = err_mode + 2*evalError(u.getModes(m),B(1:d,l),u.getModes(i));
            end
            % Compute the 2*int(s*k^-1*s) + 2*int(grad(u)*k*grad(u))
            if ~no_time
                err_mode = err_mode + evalError(s.getPGDModes(m),A([1 d+2 3:d],l),s.getPGDModes(m));
            else
                err_mode = err_mode + evalError(s.getPGDModes(m),A(:,l),s.getPGDModes(m));
            end
            err_mode = err_mode + evalError(u.getModes(m),B(1:d,l),u.getModes(m));
        end
        coor_mode = 0;
        % Compute the int(s_d*grad(u))
        for i=1:s.nbStaticModes()
            coor_mode = coor_mode + evalError(s.getStaticModes(i),C(1:d,1),u.getModes(m));
        end
        % Compute the int(s_{m-1}*grad(u)) + int(s*grad(u_{m-1}))
        for i=1:m-1
            if ~no_time
                coor_mode = coor_mode + evalError(s.getPGDModes(i),C([1 d+1 3:d],1),u.getModes(m));
                coor_mode = coor_mode + evalError(s.getPGDModes(m),C([1 d+1 3:d],1),u.getModes(i));
            else
                coor_mode = coor_mode + evalError(s.getPGDModes(i),C(1:d,1),u.getModes(m));
                coor_mode = coor_mode + evalError(s.getPGDModes(m),C(1:d,1),u.getModes(i));
            end
        end
        % Compute the int(s*grad(u)) + int(s*grad(u))
        if ~no_time
            coor_mode = coor_mode + evalError(s.getPGDModes(m),C([1 d+1 3:d],1),u.getModes(m));
            coor_mode = coor_mode + evalError(s.getPGDModes(m),C([1 d+1 3:d],1),u.getModes(m));
        else
            coor_mode = coor_mode + evalError(s.getPGDModes(m),C(1:d,1),u.getModes(m));
            coor_mode = coor_mode + evalError(s.getPGDModes(m),C(1:d,1),u.getModes(m));
        end
        err{m+1} = err{m} + err_mode - 2*coor_mode;
        norm_err{m+1} = norm_err{m} + err_mode + 2*abs(coor_mode);
    end
end

function vals = safeInv(mat)
    if all(mat < eps)
        vals = mat;
    else
        vals = inv(mat);
    end
end

function items = evalError(u,K,v)
    n = length(u.data);
    data = cell(n,1);
    for i=1:n
        if iscell(K{i})
            data{i} = cellfun(@(k) u.data{i}'*k*v.data{i},K{i});
        elseif isvector(K{i})
            data{i} = u.data{i}.*K{i}.*v.data{i};
        else
            data{i} = u.data{i}'*K{i}*v.data{i};
        end
    end
    items = pgd.outProd(data{:});
end