function u_adm = admissibleDualField(u, fd, rd, Fd)
    if u.meshes{1}.d == 1 && isa(u,'error.PGDDualSol')

        if isempty(fd)
            fd = mesh.evalOnMesh(u.meshes{1},@(x) 0);
        else
            fd = sum(cell2mat(cellfun(@(f) mesh.evalOnMesh(u.meshes{1},f),fd(1,:),'UniformOutput',false)'),2);
        end
        if isempty(rd)
            rd = mesh.evalOnMesh(u.meshes{1},@(x) 0);
        else
            rd = sum(cell2mat(cellfun(@(f) mesh.evalOnMesh(u.meshes{1},f),rd(1,:),'UniformOutput',false)'),2);
        end

        u_adm = error.PGDDualSol(u.meshes);
        u_adm.setRepresentation({'Nodes' u.kind_of_rep{2:end}}); 
        for i=1:u.nbStaticModes()
            mode = u.getStaticModes(i);
            psi = admissible(u.meshes{1},mode.data{1},fd,rd);
            u_adm.addStaticMode({psi mode.data{2:end}});
        end
        for i=1:u.nbPGDModes()
            mode = u.getPGDModes(i);
            psi = admissible(u.meshes{1},mode.data{1},fd,rd);
            u_adm.addMode({psi mode.data{2:end}});
        end
    else
        error('It''s not yet implemented or bad inputs');
    end

end

function u_adm = admissible(x,u,fd,rd)
    Mx = formulation.FEMMat(x,0,0,@(x) 1,'elementary');
    Gx = formulation.FEMMat(x,1,0,@(x) 1,'elementary');
    u_adm = sum(cell2mat(cellfun(@(m,g) 2*(m*fd - g*rd),Mx,Gx,'UniformOutput',false)'),2);
end