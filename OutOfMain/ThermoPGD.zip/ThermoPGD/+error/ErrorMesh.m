%ErrorMesh     A Decorator Mesh representation for Error Evaluation
%
%   It gives extra connectivity tables as the elem2edges, and the
%   "transpose" connectivity table of elem2edges, elems and edges.
%
%   Copyright 2014 Pierre-Eric Allier

classdef ErrorMesh < mesh.Mesh
    properties (SetAccess = protected)
        mesh; % The mesh based on
    end
    
    methods
        function obj = ErrorMesh(mesh)
        %ErrorMesh constructor to define an error mesh based on a Mesh object.
        %
        %   obj = ErrorMesh(mesh) create an error mesh based on a Mesh object
        %
        %   Example 1:
        %       % Create an empty 2D mesh of type 'TRI'
        %       x = Mesh(2, 'TRI');
        %       ErrorMesh(x);
        %
            if ~isa(mesh,'mesh.Mesh')
                error('ThermoPGD:ErrorMesh:BadInputs','Check the doc');
            end
            obj@mesh.Mesh(mesh.d,mesh.elem_type);
            obj.mesh = mesh;
            obj.nodes = mesh.nodes;
            obj.elems = mesh.elems;
        end
        
        function table = elem2edges(obj)
        %elem2edges compute the table of connectivity between the elements and the edges
        %
        %   Example:
        %       % Create the mesh
        %       x = mesh.Mesh(2,'TRI');
        %       x.addNodes([0 0;1 0;0 1;1 1]);
        %       x.addElems([1 2 3;2 4 3]);
        %       % Get the edges
        %       x.elem2edges();
        %
            edges_table = obj.mesh.edges();
            table = zeros(obj.mesh.nbElems(),size(obj.mesh.elems,2));
            for i=1:obj.mesh.nbElems()
                table(i,:) = find(all(ismember(edges_table,obj.mesh.elems(i,:)),2) > 0);
            end
        end
        
        function table = edge2elems(obj)
        %edge2elems compute the table of connectivity between the edges and
        %the elements (it's the reverse of elem2edges function)
        %
        %   Example:
        %       % Create the mesh
        %       x = mesh.Mesh(2,'TRI');
        %       x.addNodes([0 0;1 0;0 1;1 1]);
        %       x.addElems([1 2 3;2 4 3]);
        %       % Get the edges
        %       x.edge2elems();
        %
            table = reverseTableOfConnec(obj.elem2edges());
        end
        
        function table = node2elems(obj)
        %node2elems compute the table of connectivity between the nodes and
        %the elements (it's the reverse of elems function)
        %
        %   Example:
        %       % Create the mesh
        %       x = mesh.Mesh(2,'TRI');
        %       x.addNodes([0 0;1 0;0 1;1 1]);
        %       x.addElems([1 2 3;2 4 3]);
        %       % Get the edges
        %       x.node2elems();
        %
            table = reverseTableOfConnec(obj.mesh.elems());    
        end
        
        function table = node2edges(obj)
        %node2edges compute the table of connectivity between the nodes and
        %the edges (it's the reverse of edges function)
        %
        %   Example:
        %       % Create the mesh
        %       x = mesh.Mesh(2,'TRI');
        %       x.addNodes([0 0;1 0;0 1;1 1]);
        %       x.addElems([1 2 3;2 4 3]);
        %       % Get the edges
        %       x.node2edges();
        %
            table = reverseTableOfConnec(obj.mesh.edges());    
        end
        
    end
end

function table = reverseTableOfConnec(connec_table)
%reverseTableOfConnec reverse a connectivity table, a "transpose" like. 
%
%   reverseTableOfConnec(table) reverse the table where we assume the ids
%   start from 1 to N without missing integer between 1 and N.
%
    n = max(connec_table(:)); % The maximum value of connectivity id 
    
    table = zeros(n,nnz(connec_table == mode(connec_table(:))));
    for i=1:n
        [elems,~] = find(connec_table == i);
        table(i,1:length(elems)) = elems;
    end
end