function sigma_adm = EETMethod(sigma, k, fd, rd, Fd, ud)
%EETMethod compute and admissible field with the EET method requested in 
%the CRError
    disp('[-]EET METHOD');

    if ~isa(sigma,'error.PGDDualSol') && isa(sigma, 'fem.FEMSol')
        sigma_adm = fem.FEMSol(sigma.meshes);
        sigma_adm.setData(admissible(error.ErrorMesh(sigma.meshes{1}),sigma.data,k,fd,rd,Fd,ud));
        
    elseif isa(sigma,'error.PGDDualSol')
        error_space_mesh = error.ErrorMesh(sigma.meshes{1});
        sigma_adm = error.PGDDualSol(sigma.meshes);
        sigma_adm.setRepresentation({'Nodes' sigma.kind_of_rep{2:end}});
        for i=1:sigma.nbStaticModes()
            disp('   -> New admissible mode');
            mode = sigma.getStaticMode(i);
            sigma_adm.addStaticMode({admissible(error_space_mesh,mode{1},k,fd,rd,Fd,ud) mode{2:end}});
        end
        for i=1:sigma.nbPGDModes()
            disp('   -> New admissible mode');
            mode = sigma.getPGDMode(i);
            sigma_adm.addMode({admissible(error_space_mesh,mode{1},k,fd,rd,Fd,ud) mode{2:end}});
        end
    else
        error('ThermoPGD:EETMethod:UnknownInput','Check the doc');
    end    
end

function sigma_adm = admissible(x,sigma,k,fd,rd,Fd,ud)
%admissible Compute the admissible field s_adm based on the s field
%
%   s_adm = admissible(x,s,k,fd,rd,Fd) compute the s_adm field based on s 
%   field with x an ErrorMesh object, k, fd, rd, Fd the repsectively
%   conductivity, flux loading of the Thermodynamic problem
%
% TODO fem solution with time
%
    ned = x.nbEdges();
    nel = x.nbElems();
    nno = x.nbNodes();
    
    % Saved the data 
    edge2elems_data = x.edge2elems();
    node2elems_data = x.node2elems();
    node2edges_data = x.node2edges();
    edge2nodes_data = x.edges();
    elem2edges_data = x.elem2edges();
    dx_nodes = ismember((1:nno)',unique(x.freeBoundary().elems())); % id of nodes belonging to the boundary
    dx_edges = ~all(min(edge2elems_data,2),2); % logical of edges belonging to the boundary 
    du_edges = all(ismember(edge2nodes_data,find(cell2mat(cellfun(@(u) mesh.evalOnMesh(x,u),ud(1,:),'UniformOutput',false)))),2);% logical of nodes belonging to the boundary where a Dirichlet condition is imposed
    
    % Set the eta_E based on the number of elements : (1 if id_elem is the greatest, -1 otherwise)
    eta = zeros(ned, nel);
    eta(sub2ind(size(eta),(1:ned)',max(edge2elems_data,[],2))) = 1;
    [edge_ids,~,elem_ids] = find(min(edge2elems_data,[],2)); % Requested since the sub2ind can't take 0 index
    eta(sub2ind(size(eta),edge_ids,elem_ids)) = -1;
    
    %% Compute the projection over edges
    % Matrix precomputation
    Kx = formulation.FEMMat(x,1,1,@(y) eye(x.d),'gauss2nodes','elementary');
    Mx = formulation.FEMMat(x,0,0,@(y) [1;1],'gauss2nodes','elementary');
    Fd = cellfun(@(f) formulation.FEMVec(x,0,f,'elementary'),fd(1,:),'UniformOutput',false);
    Rd = cellfun(@(r) formulation.FEMVec(x.freeBoundary(),0,r,'elementary'),rd(1,:),'UniformOutput',false);
    
    % Compute the second member Q_E
    QE = cell(nel,1);
    for i=1:nel
        % Compute QE
        QE{i} = sigma'*Kx{i};
        if ~isempty(Fd)% TODO if the sol is fem with time
            QE{i} = QE{i} - sum(cell2mat(cellfun(@(r) r{i},Fd,'UniformOutput',false)),2);
        end
        %disp(['Q_E sur l''�l�ment ' num2str(i)])
        %disp(QE{i}')
    end
    
    keyboard
    
    % Store the Strength density for each edges
    b_tilde = cellfun(@(x) sparse(nno,1),num2cell(1:ned)','UniformOutput',false);
    
    % Loop over nodes
    for i=1:nno
        disp(['- Node ' num2str(i)]); 
        % Get the patch
        local_elems_id = node2elems_data(i,node2elems_data(i,:) > 0); % Ids of local elements
        local_edges_id = node2edges_data(i,node2edges_data(i,:) > 0); % Ids of local edges
        
        % Compute the matrix B
        B = zeros(length(local_elems_id), length(local_edges_id));
        F = zeros(length(local_elems_id),1);
        % Loop over elements
        for j=1:length(local_elems_id)
            inter_edge = intersect(local_edges_id,elem2edges_data(local_elems_id(j),:),'stable'); % intersection of the edges of the patch and the edges of the current element
            for l=1:length(inter_edge)
                B(j,local_edges_id == inter_edge(l)) = eta(inter_edge(l),local_elems_id(j));
            end
            F(j) = QE{local_elems_id(j)}(i);
        end
        
        keyboard
        
        % If inside node, remove one equation
        if ~dx_nodes(i)
            disp('   It''s an iner node');
            B = B(1:end-1,:);
            F = F(1:end-1);
        end     
        
        % Compute the CLs system (matrix C)
        nb_cl = sum(dx_edges(local_edges_id) & ~du_edges(local_edges_id)); % the number of CL
        disp(['   Adding ' num2str(nb_cl) ' CLs to the system']);
        C = zeros(nb_cl,length(local_edges_id));
        q = zeros(nb_cl,1);
        l = 1;
        for j=1:length(local_edges_id)
            if dx_edges(local_edges_id(j)) && ~du_edges(local_edges_id(j))
                C(l,j) = eta(local_edges_id(j),edge2elems_data(local_edges_id(j),1));
                q(l) = 0;
                if ~isempty(Rd)% TODO if the sol is fem with time
                    vals = sum(cell2mat(cellfun(@(r) r{i},Rd,'UniformOutput',false)),2);
                    q(l) = q(l) + vals(i);
                end
                l = l+1;
            end
        end
        B = [C;B];
        F = [q;F];
        
        % If too much equations reduce the matrix
        n = size(B,2);
        if size(B,1) > n
            B = B(1:n,:);
            F = F(1:n,:);
        elseif size(B,1) < n % If not enought equations add minimization condition 
            disp('   TODO : Need to add the minimization part');
            % Compute the matrix M = 1
            M = diag(ones(n,1));

            % Compute the vector b
            b = zeros(n,1);
            for j=1:length(local_edges_id)
                if dx_data(local_edges_id(j)) && ~du_data(local_edges_id(j)) % edge of df_Omega
                    elem = edge2elems_data(local_edges_id(j),1); % get the only element link to that edge
                    b(j) = 0;
                    if ~isempty(Rd)% TODO if the sol is fem with time
                        vals = sum(cell2mat(cellfun(@(r) r{i},Rd,'UniformOutput',false)),2);
                        b(j) = b(j) + 1/eta(local_edges_id(j),elem)*vals(i);
                    end
% 
%                 elseif ismember(du_data,local_edges_id(j))% edge of du_Omega
%                     elem = mesh.edge2elem(local_edges_id(j),1); % get the only element link to that edge
%                     
%                     if strcmpi(x.elem_type,'TRESS') % That imply that edges are NODE elements
%                         n = diff(x.nodes(x.elems(x.edge2elems(local_edges_id(j),1),:),:)); % The direction of the linked element
%                     else % That imply that edges are TRESS elements
%                         n = diff(x.nodes(x.edge2nodes(local_edges_id(j),:),:)); % The normal of the direction
%                     end
%                     n = n./norm(n,2);
%                    
%                     b(j) = b(j) + 1/eta(local_edges_id(j),elem)*Mx{i};
%                     keyboard
% 
%                 else % internal edge
%                     elem1 = mesh.edge2elem(local_edges_id(j),1); % get the first element link to that edge
%                     % Create a mesh with a single element the edge
%                     tmp_mesh = mesh;
%                     tmp_mesh.elem = mesh.border.elem;
%                     tmp_mesh.connec = mesh.edge2node(local_edges_id(j),:);
%                     Mdx1 = FEMMat(tmp_mesh,-1,0,1);
%                     n1 = mesh.coor(mesh.edge2node(local_edges_id(j),2),:) - mesh.coor(mesh.edge2node(local_edges_id(j),1),:);
%                     n1 = [n1(2) -n1(1)];
%                     n1 = n1./norm(n1,2);
% 
%                     elem2 = mesh.edge2elem(local_edges_id(j),2); % get the second element link to that edge
%                     % Create a mesh with a single element, the edge
%                     tmp_mesh = mesh;
%                     tmp_mesh.elem = mesh.border.elem;
%                     tmp_mesh.connec = mesh.edge2node(local_edges_id(j),:);
%                     Mdx2 = FEMMat(tmp_mesh,-1,0,1);
%                     n2 = mesh.coor(mesh.edge2node(local_edges_id(j),2),:) - mesh.coor(mesh.edge2node(local_edges_id(j),1),:);
%                     n2 = [n2(2) -n2(1)];
%                     n2 = -n2./norm(n2,2);
% 
%                     b(j) = sum(1/2*(1/eta(elem1,local_edges_id(j))*mean(reshape(bsxfun(@dot,reshape(sigma(nsigma_elem*(elem1-1)+1:nsigma_elem*elem1),2,nsigma_elem/2),repmat(n1',1,nsigma_elem/2)),sqrt(nsigma_elem/2),sqrt(nsigma_elem/2)),1)*Mdx1(:,mesh.edge2node(local_edges_id(j),mesh.edge2node(local_edges_id(j),:) > 0)) + ...
%                                 1/eta(elem2,local_edges_id(j))*mean(reshape(bsxfun(@dot,reshape(sigma(nsigma_elem*(elem1-1)+1:nsigma_elem*elem1),2,nsigma_elem/2),repmat(n2',1,nsigma_elem/2)),sqrt(nsigma_elem/2),sqrt(nsigma_elem/2)),1)*Mdx2(:,mesh.edge2node(local_edges_id(j),mesh.edge2node(local_edges_id(j),:) > 0))));
                end
            end
            B = [M B';B zeros(size(B,1))];
            F = [M*b;F];
        end
       
        keyboard
        
        % Compute the density projections b_tilde from the previous b_E
        b = B\F;
        for j=1:length(local_edges_id)
            b_tilde{local_edges_id(j)}(i) = b(j);
        end

        disp(['   Sol: ' num2str(b')]);
    end
        
    %% Compute the density from projections
    if strcmpi(x.elem_type,'TRESS')
        y = mesh.Mesh(x.d,'NODE');
    else
        y = mesh.Mesh(x.d,'TRESS');
    end
    y.addNodes(x.nodes);
    y.addElems(x.edges);
    
    Mx = formulation.FEMMat(y,0,0,@(x) 1,'elementary');
        
    F_tilde = cell(ned,1);
    for i=1:ned
        F_tilde{i} = zeros(nno,1);
        Mx{i}(edge2nodes_data(i,:),edge2nodes_data(i,:))\b_tilde{i}(edge2nodes_data(i,:));
    end
    
    %% Verification of the equilibrium
    err = zeros(nel,1);
    
    K = formulation.FEMMat(x,1,1,@(y) ones(x.d),'elementary');
    Fd = cellfun(@(f) formulation.FEMVec(x,0,f,'elementary'),fd(1,:),'UniformOutput',false);
    Rd = cellfun(@(r) formulation.FEMVec(x.freeBoundary(),0,r,'elementary'),rd(1,:),'UniformOutput',false);
    
%     for i=1:nel
%         local_edges_id = mesh.elem2edge(i,:); % id of the edges of the current element
%         F = zeros(size(mesh.coor,1),1);
%         for j=1:length(local_edges_id) % loop over edges of the elements
%             tmp_border = struct('elem',mesh.border.elem,'formul',mesh.formul,'coor',tmp_mesh.coor,'connec',mesh.edge2node(local_edges_id(j),:));
%             f = FEMVec(tmp_border,0,1);
%             id = mesh.edge2node(local_edges_id(j),:);
% 
%             xe = mesh.coor(mesh.edge2node(local_edges_id(j),:),:);
%             n = xe(2,:) - xe(1,:);
%             t = abs([n(2) -n(1)]);
%             t = t./norm(t,2);
% 
%             F = F + f(:,sort([2*(id-1)+1 2*id]))*eta(i,local_edges_id(j))*reshape(bsxfun(@(t,f) t*f,t,F_tilde{local_edges_id(j)})',[],1);
%         end
%         F = Fd*fd + F;
% 
%         err(i) = ones(size(K,1),1)'*(K*ones(size(K,1),1) - F);
% 
%         disp(['Erreur sur l''�l�ment ' num2str(i) ' : ' num2str(err(i))])
%     end

    disp(['Error of equilibrium : ' num2str(norm(err,2))]);
    
    %% Compute the admissible field from the previous density
    sigma_adm = cell(nel,1);

    for i=1:nel
        % Create a mesh with refined element
        
        % Test of the increase order

        % Compute the nodal values of the loading
      
        % Compute the rigidity matrix
       
        % Compute the second member

        % Remove the rigid-body displacement

        % Solve -> get the displacement

        % Reconstruction of the admissible field from the displacement
        
        % Get the admissible field for the current element on the gauss points
        sigma_adm{i} = 0;
    end
    sigma_adm = cell2mat(sigma_adm);
    
    keyboard
end