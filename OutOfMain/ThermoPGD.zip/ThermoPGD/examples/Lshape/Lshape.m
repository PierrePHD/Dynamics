addpath('../../'); % Add the library

import mesh.*; % Import the mesh library
import fem.*; % Import the fem library
import pgd.*; % Import the pgd library
import error.*; % Import the error library

%% Mesh
% Parameter
L = 1; % Length of the square (space)
dt = 1/10; % Discretization size of time
dk1 = 1/20; % Discretization size of conductivity of the space mesh

% Create the mesh
x = loadGmshMesh('./Lshape.msh','TRI');
t = segmentMesh(0:dt:1);
k1 = segmentMesh(10.^(0:2*dk1:2));

mesh = cell(3,1);
mesh{1} = x;
mesh{2} = t;
mesh{3} = k1;

%% Problem formulation c*du/dt+k*grad(u) + fd = 0
% Parameter
c0 = 0.01; % Specific Heat, constant over the space

% Dirichlet conditions
ud = cell(3,1);
ud{1,1} = @(x) x(2) == 0;
ud{2,1} = @(t) t(1) == 0;
ud{3,1} = @(k1) 0;

% Conductivity condition
k = cell(3,1);
k{1,1} = @(x) [1 0;0 1];
k{2,1} = @(t) 1;
k{3,1} = @(k1) k1;

% Specific heat 
c = cell(3,1);
c{1,1} = @(x) c0;
c{2,1} = @(t) 1;
c{3,1} = @(k1) 1;

% Volumic flux
fd = cell(3,1);
fd{1,1} = @(x) 200*x(1)*x(2);
fd{2,1} = @(t) 1;
fd{3,1} = @(k1) 1;

% Linear flux
rd = cell(3,1);
rd{1,1} = @(x) 10*[abs(x(1) - 2*L) < eps 0]';
rd{2,1} = @(t) t(1);
rd{3,1} = @(k1) 1;

% Discrete flux
Fd = cell(3,0);

%% Solver
u_fem = femSolver(mesh, c, k, ud, fd, rd, Fd, 0.5);
u_pgd = pgdSolver(mesh, c, k, ud, fd, rd, Fd, 10, 8);

%% Dual field computation
s_fem = femDualField(u_fem, k);
s_pgd = pgdDualField(u_pgd, c, k, ud, fd, rd, Fd);

%% Plot
disp('[-]POST-PROCESSING')
plotSol(u_fem,'xlabel',{'x','t','k1'},'ylabel','sol','title','FEM Sol','fixedaxis',true);
plotSol(u_pgd,'xlabel',{'x','t','k1'},'ylabel','sol','title','PGD Sol','fixedaxis',true);

err = FEMSol(u_fem.meshes);
err.setData(u_pgd.fullRep() - u_fem.fullRep());

plotSol(err,'xlabel',{'x','t','k1'},'ylabel','Temperature','title','Error','fixedaxis',true);
plotSol(s_fem,'xlabel',{'x','t','k1'},'ylabel','Flux','title','FEM Dual Sol.','fixedaxis',true);
plotSol(s_pgd,'xlabel',{'x','t','k1'},'ylabel','Flux','title','PGD Dual Sol.','fixedaxis',true);

figure('Name','Modes PGD');
    subplot(2,2,1);
        plotOnNodes(x,u_pgd.data{1}(:,1));
        xlabel('x');
        ylabel('y');
    subplot(2,2,2);
        plot(t.nodes,u_pgd.data{2});
        xlabel('t');
        ylabel('\lambda');
    subplot(2,2,3);
        plot(k1.nodes,u_pgd.data{3});
        xlabel('k_1');
        ylabel('\gamma_1');
        
 %plotErrSol(mesh,err,'xlabel',{'x','t','k1','k2'},'ylabel','sol','title','plot','fixedaxis',true);

