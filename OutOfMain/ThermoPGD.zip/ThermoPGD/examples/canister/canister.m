%% Canister Square problem
%
% It represents the transport of pollutant inside an active carbon filter. 
% The concentration of pollutant u satisfies the following advection-
% diffusion-reaction problem.
%
% See Nouy "A priori model reduction through Proper Generalized
% Decomposition for solving time-dependent partial differntial equations"
% 2010

addpath('../../'); % Add the library

import mesh.*; % Import the mesh library
import fem.*; % Import the fem library
import pgd.*; % Import the pgd library
import utils.*; % Usefull functions

%% Parameter of the case
L = 1; % Length of the square
l1 = 0.3; % Length of the in/out part
l2 = 0.5; % Length of the center part
h = 0.6; % Height of the upper part
T = 100; % Final time
nt = 100; % Number of elements in time

%% Mesh
x = loadGmshMesh('./canister.msh','TRI');
t = segmentMesh(0:T/nt:T);

%% Problem c*du/dt + k*d^2u/dx^2 + f*u = 0
c = cell(2,1);
c{1,1} = @(x) 1;
c{2,1} = @(t) 1;

k = cell(2,1);
k{1,1} = @(x) 0.1*[1 0;0 1];
k{2,1} = @(t) 1;

f = cell(2,2);
f{1,1} = @(x) 0.01*(x(2) <= L);
f{2,1} = @(t) 1;
f{1,2} = @(x) 10*(x(2) >= L && x(1) <= l1);
f{2,2} = @(t) 1; 

ud = cell(2,1);
ud{1,1} = @(x) x(1) >= l1+l2 && x(2) == 0|| x(1) <= l1 && x(2) == L+h;
ud{2,1} = @(t) t == 0;

v = cell(2,1);
v{1,1} = @(x) x(1) >= l1+l2 && x(2) == 0;
v{2,1} = @(t) 1;

%% Solving
u_fem = pollutionFemSolver({x,t},c,k,f,ud,v,0.5);
u_pgd = pollutionPgdSolver({x,t},c,k,f,ud,v,10,4);

%% Post-processing
disp('[-]POST-PROCESSING');

plotFEMSol({x,t}',u_fem,'xlabel',{'x','t'},'ylabel','Temperature','title','FEM Sol.','fixedaxis',true);
plotPGDSol({x,t}',u_pgd,'xlabel',{'x','t'},'ylabel','Temperature','title','PGD Sol.','fixedaxis',true);

i = min(10,u_pgd.nbModes()); % Plot only the first ten modes or less
figure('Name','Modes PGD');
    subplot(3,2,[1 3]);
        plotOnNodes(x,u_pgd.data{1});
        xlabel('x');
        ylabel('y');
    subplot(3,2,[2 4]);
        h = plot(t.nodes,u_pgd.data{2}(:,1:i));
        xlabel('t');
        ylabel('\lambda');
    subplot(3,2,[5 6]);
    axis off;
    gridLegend(h,4,num2str((1:i)','%i-th mode'),'Location','SouthOutside');
        