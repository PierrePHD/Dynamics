addpath('../../'); % Add the library

import mesh.*; % Import the mesh library
import fem.*; % Import the fem library
import pgd.*; % Import the pgd library
import error.*; % Import the error library

%% Mesh
% Parameter
L = 1; % Length of the square (space)
dx = L/200; % Discretization size of space mesh
dk1 = 1/200; % Discretization size of parameter mesh

mesh = cell(3,1);
mesh{1} = segmentMesh(0:dx:L);
mesh{2} = segmentMesh(10.^(0:5*dk1:2));
mesh{3} = segmentMesh(0.1*10.^(0:5*dk1:2));

%% Problem formulation c*du/dt+k*grad(u) + fd = 0
% Dirichlet conditions
ud = cell(3,1);
ud{1,1} = @(x) x(1) == 0;
ud{2,1} = @(k1) 0;
ud{3,1} = @(k2) 0;

% Conductivity condition
k = cell(3,2);
k{1,1} = @(x) x(1) <= L/2;
k{2,1} = @(k1) k1;
k{3,1} = @(k2) 1;

k{1,2} = @(x) x(1) >= L/2;
k{2,2} = @(k1) 1;
k{3,2} = @(k2) k2;

% Specific heat 
c = cell(3,0);

% Volumic flux
fd = cell(3,0);

% Linear flux
rd = cell(3,1);
rd{1,1} = @(x) x(1) == L;
rd{2,1} = @(k1) 1;
rd{3,1} = @(k2) 1;

% Discrete flux
Fd = cell(3,0);

%% Solver
u_fem = femSolver(mesh, c, k, ud, fd, rd, Fd, 0.5, true);
u_pgd = pgdSolver(mesh, c, k, ud, fd, rd, Fd, 10, 4, true);

%% Plot
disp('[-]POST-PROCESSING')
plotFEMSol(mesh,u_fem,'xlabel',{'x','k1','k2'},'ylabel','sol','title','FEM Sol','fixedaxis',true);
plotPGDSol(mesh,u_pgd,'xlabel',{'x','k1','k2'},'ylabel','sol','title','PGD Sol','fixedaxis',true);

figure('Name','Modes PGD');
    subplot(2,2,1);
        plot(mesh{1}.nodes,u_pgd.data{1});
        xlabel('x');
        ylabel('\psi');
    subplot(2,2,2);
        plot(mesh{2}.nodes,u_pgd.data{2});
        xlabel('k1');
        ylabel('\gamma_1');
    subplot(2,2,3);
        plot(mesh{3}.nodes,u_pgd.data{3});
        xlabel('k2');
        ylabel('\gamma_2');