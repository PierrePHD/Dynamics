%% Ludo Square problem
%
% A transient thermal problem with a source term fd(x,y) = 200*x*y and a
% flux on the 2 rectangular holes where a fluid circulate where rd = -1

addpath('../../'); % Add the library

import mesh.*; % Import the mesh library
import fem.*; % Import the fem library
import pgd.*; % Import the pgd library
import utils.*; % Usefull functions

%% Parameter of the case
L = 1; % Length of the square
y = 0.625; % Position of the center of the hole from the center of the square (*L)
h = 0.25; % Height of the hole (*L)
l = 0.5; % Length of the half of the hole (*L)
T = 10; % Final time
nt = 5; % Number of elements in time
dk = 1/5; % Number of parameter elements
d = 4; % Number of parameter in conductivity to take into account (max 4)
g = [0.1 0.1 0.2 0.05];

%% Mesh
d = min(d,4);
mesh = cell(3+d,1);
mesh{1} = loadGmshMesh('./ludo_case.msh','TRI');
mesh{2} = segmentMesh(0:T/nt:T);
for i=1:d
    mesh{i+2} = segmentMesh(0:2*dk:2);
end
mesh{end} = segmentMesh(0:2*dk:2);

%% Problem formulation  c*du/dt+k*grad(u) + fd = 0
c = cell(3+d,2);
c{1,1} = @(x) 1;
c{2,1} = @(t) 1;
for i=1:d
    c{2+i,1} = @(k1) 1;
end
c{end,1} = @(k5) 1; 
c{1,2} = @(x) 1;
c{2,2} = @(t) 1;
for i=1:d
    c{2+i,2} = @(k1) 1;
end
c{end,2} = @(k5) 0.2*k5;

k = cell(3+d,d+1);
k{1,1} = @(x) [1 0;0 1];
k{2,1} = @(t) 1;
for i=1:d
    k{2+i,1} = @(k1) 1;
end
k{end,1} = @(k5) 1;
for j=1:d
    switch j
        case 1
            k{1,j+1} = @(x) [1 0;0 1]*(x(1) <= l*L && x(2) >= (y+h/2)*L);
        case 2
            k{1,j+1} = @(x) [1 0;0 1]*(x(1) >= l*L && x(2) >= (y-h/2)*L);
        case 3
            k{1,j+1} = @(x) [1 0;0 1]*(x(1) >= l*L && x(2) <= (y-h/2)*L);
        case 4
            k{1,j+1} = @(x) [1 0;0 1]*(x(1) <= l*L && x(2) <= (y-h/2)*L);
    end
    k{2,j+1} = @(t) 1;
    for i=1:d
        if i == j
            k{2+i,j+1} = @(k) g(i)*k;
        else
            k{2+i,j+1} = @(k) 1;
        end
    end
    k{end,j+1} = @(k5) 1;
end

fd = cell(3+d,1);
fd{1,1} = @(x) 200*x(1)*x(2);
fd{2,1} = @(t) 1;
for i=1:d
    fd{2+i,1} = @(k1) 1;
end
fd{end,1} = @(k5) 1;

rd = cell(3+d,3);
rd{1,1} = @(x) -(x(2) == (y-h/2)*L && x(1) <= l*L)*[0 1]';
rd{2,1} = @(t) 1;
for i=1:d
    rd{2+i,1} = @(k1) 1;
end
rd{end,1} = @(k5) 1;
rd{1,2} = @(x) -(x(2) == (y+h/2)*L && x(1) < L || x(2) == 0)*[0 1]';
rd{2,2} = @(t) 1;
for i=1:d
    rd{2+i,2} = @(k1) 1;
end
rd{end,2} = @(k5) 1;
rd{1,3} = @(x) -(x(2) >= (y-h/2)*L && x(2) <= (y+h/2)*L  && x(1) == l*L || x(1) == 0)*[1 0]';
rd{2,3} = @(t) 1;
for i=1:d
    rd{2+i,3} = @(k1) 1;
end
rd{end,3} = @(k5) 1;

Fd = cell(3+d,0);

ud = cell(3+d,1);
ud{1,1} = @(x) 0;
ud{2,1} = @(t) t == 0;
for i=1:d
    ud{2+i,1} = @(k1) 0;
end
ud{end,1} = @(k5) 0;

%% Solution computation
u_fem = femSolver(mesh, c, k, ud, fd, rd, Fd, 0.5);
u_pgd = pgdSolver(mesh, c, k, ud, fd, rd, Fd, 10, 4);

%% Post-processing
disp('[-]POST-PROCESSING')
text_legend = cell(d+3,1);
text_legend{1} = 'x';
text_legend{2} = 't';
for i=1:d
    text_legend{i+2} = ['theta_' num2str(i)];
end
text_legend{end} = 'theta_5';


plotFEMSol(mesh,u_fem,'xlabel',text_legend,'ylabel','Temperature','title','FEM Sol.','fixedaxis',true);
plotPGDSol(mesh,u_pgd,'xlabel',text_legend,'ylabel','Temperature','title','PGD Sol.','fixedaxis',true);

plotFEMSol(mesh, u_pgd.fullTensor() - u_fem,'xlabel',text_legend,'ylabel','Temperature','title','Error','fixedaxis',true);

m = min(10,u_pgd.nbModes()); % Plot only the first ten modes or less
figure('Name','Modes PGD');
    subplot(ceil(d/2)+2,2,1);
        plotOnNodes(mesh{1},u_pgd.data{1}(:,1:m));
        xlabel('x');
        ylabel('\psi');
        colorbar;
    subplot(ceil(d/2)+2,2,2);
        plot(mesh{2}.nodes,u_pgd.data{2}(:,1:m));
        xlabel('t');
        ylabel('\lambda');
    for i=1:d
        subplot(ceil(d/2)+2,2,2+i);
        plot(mesh{2+i}.nodes,u_pgd.data{2+i}(:,1:m));
        xlabel(['theta_' num2str(i)]);
        ylabel(['\gamma_' num2str(i)]);
    end
    subplot(ceil(d/2)+2,2,2*(ceil(d/2)+1)+(1:2))
        h = plot(mesh{end}.nodes,u_pgd.data{end}(:,1:m));
        xlabel('theta_5');
        ylabel('\gamma_5');
    legend(h,num2str((1:m)','%i-th mode'),'Location','EastOutside');        
        