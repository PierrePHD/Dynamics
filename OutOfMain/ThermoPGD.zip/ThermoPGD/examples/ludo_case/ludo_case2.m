%% Ludo Square problem
%
% A transient thermal problem with a source term fd(x,y) = 200*x*y and a
% flux on the 2 rectangular holes where a fluid circulate where rd = -1

addpath('../../'); % Add the library

import mesh.*; % Import the mesh library
import fem.*; % Import the fem library
import pgd.*; % Import the pgd library
import utils.*; % Usefull functions
import error.*; % Import the error library

%% Parameter of the case
L = 1; % Length of the square
y = 0.625; % Position of the center of the hole from the center of the square (*L)
h = 0.25; % Height of the hole (*L)
l = 0.5; % Length of the half of the hole (*L)
T = 10; % Final time
nt = 100; % Number of elements in time
dk = 1/20; % Number of parameter elements
d = 0; % Number of parameter in conductivity to take into account (max 4)
g = [0.1 0.1 0.2 0.05];

%% Mesh
d = min(d,4);
mesh = cell(2+d,1);
mesh{1} = loadGmshMesh('./ludo_case.msh','TRI');
mesh{2} = segmentMesh(0:T/nt:T);
for i=1:d
    mesh{i+2} = segmentMesh(0:4*dk:2);
end

%% Problem formulation  c*du/dt+k*grad(u) + fd = 0
c = cell(2+d,1);
c{1,1} = @(x) 1;
c{2,1} = @(t) 1;
for i=1:d
    c{2+i,1} = @(k1) 1;
end 

k = cell(2+d,d+1);
k{1,1} = @(x) [1 0;0 1];
k{2,1} = @(t) 1;
for i=1:d
    k{2+i,1} = @(k1) 1;
end

for j=1:d
    switch j
        case 1
            k{1,j+1} = @(x) [1 0;0 1]*(x(1) <= l*L && x(2) >= (y+h/2)*L);
        case 2
            k{1,j+1} = @(x) [1 0;0 1]*(x(1) >= l*L && x(2) >= (y-h/2)*L);
        case 3
            k{1,j+1} = @(x) [1 0;0 1]*(x(1) >= l*L && x(2) <= (y-h/2)*L);
        case 4
            k{1,j+1} = @(x) [1 0;0 1]*(x(1) <= l*L && x(2) <= (y-h/2)*L);
    end
    k{2,j+1} = @(t) 1;
    for i=1:d
        if i == j
            k{2+i,j+1} = @(k) g(i)*k;
        else
            k{2+i,j+1} = @(k) 1;
        end
    end
    k{end,j+1} = @(k5) 1;
end

fd = cell(2+d,1);
fd{1,1} = @(x) 200*x(1)*x(2);
fd{2,1} = @(t) 1;
for i=1:d
    fd{2+i,1} = @(k1) 1;
end

rd = cell(2+d,3);
rd{1,1} = @(x) -(x(2) == (y-h/2)*L && x(1) <= l*L)*[0 1]';
rd{2,1} = @(t) 1;
for i=1:d
    rd{2+i,1} = @(k1) 1;
end

rd{1,2} = @(x) -(x(2) == (y+h/2)*L && x(1) < L || x(2) == 0)*[0 1]';
rd{2,2} = @(t) 1;
for i=1:d
    rd{2+i,2} = @(k1) 1;
end

rd{1,3} = @(x) -(x(2) >= (y-h/2)*L && x(2) <= (y+h/2)*L  && x(1) == l*L || x(1) == 0)*[1 0]';
rd{2,3} = @(t) 1;
for i=1:d
    rd{2+i,3} = @(k1) 1;
end

Fd = cell(2+d,0);

ud = cell(2+d,1);
ud{1,1} = @(x) 0;
ud{2,1} = @(t) t == 0;
for i=1:d
    ud{2+i,1} = @(k1) 0;
end

%% Solution computation
u_fem = femSolver(mesh, c, k, ud, fd, rd, Fd, 0.5);
u_pgd = pgdSolver(mesh, c, k, ud, fd, rd, Fd, 10, 4);

%% Dual field computation
s_fem = femDualField(u_fem, k);
s_pgd = pgdDualField(u_pgd, c, k, ud, fd, rd, Fd);

%% Post-processing
disp('[-]POST-PROCESSING')
text_legend = cell(d+2,1);
text_legend{1} = 'x';
text_legend{2} = 't';
for i=1:d
    text_legend{i+2} = ['theta_' num2str(i)];
end

plotSol(u_fem,'xlabel',text_legend,'ylabel','Temperature','title','FEM Sol.','fixedaxis',true);
plotSol(u_pgd,'xlabel',text_legend,'ylabel','Temperature','title','PGD Sol.','fixedaxis',true);

err = FEMSol(u_fem.meshes);
err.setData(u_pgd.fullRep() - u_fem.fullRep());

plotSol(err,'xlabel',text_legend,'ylabel','Temperature','title','Error','fixedaxis',true);
plotSol(s_fem,'xlabel',text_legend,'ylabel','Flux','title','FEM Dual Sol.','fixedaxis',true);
plotSol(s_pgd,'xlabel',text_legend,'ylabel','Flux','title','PGD Dual Sol.','fixedaxis',true);

m = min(10,u_pgd.nbModes()); % Plot only the first ten modes or less
figure('Name','Modes PGD');
    subplot(ceil(d/2)+2,2,1);
        plotOnNodes(mesh{1},u_pgd.data{1}(:,1));
        xlabel('x');
        ylabel('\psi');
        colorbar;
    subplot(ceil(d/2)+2,2,2);
        h = plot(mesh{2}.nodes,u_pgd.data{2}(:,1:m));
        xlabel('t');
        ylabel('\lambda');
    for i=1:d
        subplot(ceil(d/2)+2,2,2+i);
        plot(mesh{2+i}.nodes,u_pgd.data{2+i}(:,1:m));
        xlabel(['theta_' num2str(i)]);
        ylabel(['\gamma_' num2str(i)]);
    end
    legend(h,num2str((1:m)','%i-th mode'),'Location','EastOutside');        
        