%% Diez Square problem with 4 materials
%
% A stationnary thermal problem with a different material in the 3 holes
% with a rd = 1 on the top

addpath('../../'); % Add the library

import mesh.*; % Import the mesh library
import fem.*; % Import the fem library
import pgd.*; % Import the pgd library
import utils.*; % Usefull functions


%% Parameter of the case
L = 1;
x1 = 0.75;
y1 = 0.75;
d1 = 0.2;

x2 = 0.25;
y2 = 0.25;
d2 = 0.2;

x3 = 0.5;
y3 = 0.5;
d3 = 0.2;

K1 = [1 100];
nk1 = 10;
K2 = [0.1 10];
nk2 = 10;
K3 = [10 1000];
nk3 = 10;

%% Mesh
x = loadGmshMesh('./diez_case2.msh','TRI'); % Load the mesh
k1 = segmentMesh(10.^(log10(K1(1)):diff(log10(K1))/nk1:log10(K1(2))));
k2 = segmentMesh(10.^(log10(K2(1)):diff(log10(K2))/nk2:log10(K2(2))));
k3 = segmentMesh(10.^(log10(K3(1)):diff(log10(K3))/nk3:log10(K3(2))));

%% Formulation c*du/dt+k*grad(u) + fd = 0
c = cell(4,0);

k = cell(4,4);
k{1,1} = @(x) 10*[1 0;0 1];
k{2,1} = @(k1) 1;
k{3,1} = @(k2) 1;
k{4,1} = @(k3) 1;
k{1,2} = @(x) [1 0;0 1]*(sqrt((x(1)-x1)^2+(x(2)-y1)^2) <= d1/2+eps);
k{2,2} = @(k1) k1;
k{3,2} = @(k2) 1;
k{4,2} = @(k3) 1;
k{1,3} = @(x) [1 0;0 1]*(sqrt((x(1)-x2)^2+(x(2)-y2)^2) <= d2/2+eps);
k{2,3} = @(k1) 1;
k{3,3} = @(k2) k2;
k{4,3} = @(k3) 1;
k{1,4} = @(x) [1 0;0 1]*(sqrt((x(1)-x3)^2+(x(2)-y3)^2) <= d3/2+eps);
k{2,4} = @(k1) 1;
k{3,4} = @(k2) 1;
k{4,4} = @(k3) k3;

fd = cell(4,0);

rd = cell(4,1);
rd{1,1} = @(x) 100*[0 x(2) == L]';
rd{2,1} = @(k1) 1;
rd{3,1} = @(k2) 1;
rd{4,1} = @(k3) 1;

Fd = cell(4,0);

ud = cell(4,1);
ud{1,1} = @(x) x(2) == 0;
ud{2,1} = @(k1) 0;
ud{3,1} = @(k2) 0;
ud{4,1} = @(k3) 0;

%% Solver
u_fem = femSolver({x,k1,k2,k3}', c, k, ud, fd, rd, Fd, 0.5, true);
u_pgd = pgdSolver({x,k1,k2,k3}', c, k, ud, fd, rd, Fd, 10, 8, true);

%% Plot
disp('[-]POST-PROCESSING')
plotFEMSol({x,k1,k2,k3}',u_fem,'xlabel',{'x','k1','k2','k3'},'ylabel','sol','title','FEM Sol','fixedaxis',true);

plotPGDSol({x,k1,k2,k3}',u_pgd,'xlabel',{'x','k1','k2','k3'},'ylabel','sol','title','PGD Sol','fixedaxis',true);

figure('Name','Modes PGD');
    subplot(2,2,1);
        plotOnNodes(x,u_pgd.data{1});
        xlabel('x');
        ylabel('y');
    subplot(2,2,2);
        plot(k1.nodes,u_pgd.data{2});
        xlabel('k_1');
        ylabel('\gamma_1');
    subplot(2,2,3);
        plot(k2.nodes,u_pgd.data{3});
        xlabel('k_2');
        ylabel('\gamma_2');
    subplot(2,2,4);
        plot(k3.nodes,u_pgd.data{4});
        xlabel('k_3');
        ylabel('\gamma_3');