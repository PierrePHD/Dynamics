%% Beam Test Case
%
% A 1D beam test case with space and time as variables
%
%  |----------------- -> rd
%  0                
%
% The loading is rd(t) = 1.
% The specific heat is c = c0
%
% The exact solution is unknown

addpath('../../'); % Add the library

import mesh.*; % Import the mesh library
import fem.*; % Import the fem library
import pgd.*; % Import the pgd library
import utils.*; % Usefull functions
import error.*; % Import the error library

%% Parameter of the case
L = 1; % Length of the beam
nx = 10; % Number of elements in space
T = 1; % Final time
nt = 100; % Number of elements in time

c0 = 0.1;

%% Mesh
x = segmentMesh(0:L/nx:L);
t = segmentMesh(0:T/nt:T);

%% Problem formulation c*du/dt+k*grad(u) + fd = 0
c = cell(2,1);
c{1,1} = @(x) c0;
c{2,1} = @(t) 1;

k = cell(2,1);
k{1,1} = @(x) 1;
k{2,1} = @(t) 1;

fd = cell(2,0);
rd = cell(2,1);
rd{1,1} = @(x) x == L;
rd{2,1} = @(t) t ~= 0;

Fd = cell(2,0);

ud = cell(2,1);
ud{1,1} = @(x) x == 0;
ud{2,1} = @(t) t == 0;

%% Solution computation
u_fem = femSolver({x,t}', c, k, ud, fd, rd, Fd, 0.5);
u_pgd = pgdSolver({x,t}', c, k, ud, fd, rd, Fd, 10, 4);

%% Dual field computation
s_fem = femDualField(u_fem, k);
s_pgd = pgdDualField(u_pgd, c, k, ud, fd, rd, Fd);
 
%% Admissible field computation
s_adm_pgd = admissibleDualField(s_pgd, fd, rd, Fd);
 
%% Error evaluation
[e_pgd,norm_e_pgd] = CRError(u_pgd,s_pgd,k);
%[e_total,norm_e_total] = CRError(u_pgd,s_adm_pgd,k);
%e_dis = cellfun(@(e_t,e_p) e_t - e_p,e_total,e_pgd,'UniformOutput',false);

%% Post-processing
disp('[-]POST-PROCESSING')
plotSol(u_fem,'xlabel',{'x','t'},'ylabel','Temperature','title','FEM Sol.','fixedaxis',true);
plotSol(u_pgd,'xlabel',{'x','t'},'ylabel','Temperature','title','PGD Sol.','fixedaxis',true);

err = FEMSol(u_fem.meshes);
err.setData(u_pgd.fullRep() - u_fem.fullRep());

plotSol(err,'xlabel',{'x','t'},'ylabel','Temperature','title','Error','fixedaxis',true);
plotSol(s_fem,'xlabel',{'x','t'},'ylabel','Flux','title','FEM Dual Sol.','fixedaxis',true);
plotSol(s_pgd,'xlabel',{'x','t'},'ylabel','Flux','title','PGD Dual Sol.','fixedaxis',true);

figure('Name','Errors');
    err = e_pgd{end}./norm_e_pgd{end};
    subplot(2,1,1);
        imagesc(err);
        colorbar
        xlabel('x');
        ylabel('t');
        zlabel('e_{CR}(x,t)');
    subplot(2,1,2);
        err_pgd = cellfun(@(e) sqrt(1/2*sum(e(:))),e_pgd);
        err_tot = cellfun(@(e) sqrt(1/2*sum(e(:))),e_total);
        norm_err = cellfun(@(e) sqrt(1/2*sum(e(:))),norm_e_pgd);
        plot(0:u_pgd.nbModes(),err_pgd./norm_err);
        xlabel('modes');
        ylabel('error');
        legend('Total Error','PGD Error');

i = min(10,u_pgd.nbModes()); % Plot only the first ten modes or less
figure('Name','Modes PGD');
    subplot(5,2,[1 3]);
        plot(x.nodes,u_pgd.data{1}(:,1:i));
        xlabel('x');
        ylabel('\psi');
    h1 = subplot(5,2,[2 4]);
        h = plot(t.nodes,u_pgd.data{2}(:,1:i));
        xlabel('t');
        ylabel('\lambda');
        gridLegend(h,4,num2str((1:i)','%i-th mode'),'Location','SouthOutside');
        