%% Beam Test Case
%
% A 1D beam test case with space and conductivity as variables
%
%  |----------------- -> rd = 1
%  0                 
%
% Half of the beam is a conductivity parameter k1, the other half is the
% second conductivity parameter k2
%
% The exact solution is known for f(x) = 1 (and easy to get for any kind of
% loading in x)
%
%   N(x,k1,k2) = 1
%
%   T(x,k1,k2) = x/k1  on x <= L/2
%   T(x,k1,k2) = (x-L/2)/k2 + L/(2*k1) on x >= L/2
%

addpath('../../'); % Add the library

import mesh.*; % Import the mesh library
import fem.*; % Import the fem library
import pgd.*; % Import the pgd library
import utils.*; % Usefull functions
import error.*; % Import the error library

%% Parameter of the case
L = 1; % Length of the beam
nx = 10; % Number of elements in space
K1 = [1 100]; % Conductivity domain of the first material
nk1 = 10; % Number of elements for the 1st parameter
K2 = [0.1 10]; % Conductivity doamin of the second material
nk2 = 10; % Number of elements for the 2nd parameter

%% Mesh
x = segmentMesh(0:L/nx:L);
k1 = segmentMesh(10.^(log10(K1(1)):diff(log10(K1))/nk1:log10(K1(2))));
k2 = segmentMesh(10.^(log10(K2(1)):diff(log10(K2))/nk2:log10(K2(2))));

%% Problem formulation c*du/dt+k*grad(u) + fd = 0
c = cell(3,0);

k = cell(3,2);
k{1,1} = @(x) double(x <= L/2);
k{2,1} = @(k1) k1;
k{3,1} = @(k2) 1;
k{1,2} = @(x) double(x >= L/2);
k{2,2} = @(k1) 1;
k{3,2} = @(k2) k2;

fd = cell(3,0);
rd = cell(3,1);
rd{1,1} = @(x) x == L;
rd{2,1} = @(k1) 1;
rd{3,1} = @(k2) 1;

Fd = cell(3,0);

ud = cell(3,1);
ud{1,1} = @(x) x == 0;
ud{2,1} = @(k1) 0;
ud{3,1} = @(k2) 0;

%% Solution computation
u_fem = femSolver({x,k1,k2}', c, k, ud, fd, rd, Fd, 0.5, true);
u_pgd = pgdSolver({x,k1,k2}', c, k, ud, fd, rd, Fd, 30, 4, true);

%% Dual field computation
s_fem = femDualField(u_fem, k);
s_pgd = pgdDualField(u_pgd, c, k, ud, fd, rd, Fd, true);
 
%% Admissible field computation
%s_adm_pgd = admissibleDualField(s_pgd, fd, rd, Fd);
 
%% Error evaluation
[e_pgd,norm_e_pgd] = CRError(u_pgd,s_pgd,k,true);
%[e_total,norm_e_total] = CRError(u_pgd,s_adm_pgd,k,true);
%e_dis = cellfun(@(e_t,e_p) e_t - e_p,e_total,e_pgd,'UniformOutput',false);

%% Post-processing
disp('[-]POST-PROCESSING')
plotSol(u_fem,'xlabel',{'x','k1','k2'},'ylabel','Temperature','title','FEM Sol.','fixedaxis',true);
plotSol(u_pgd,'xlabel',{'x','k1','k2'},'ylabel','Temperature','title','PGD Sol.','fixedaxis',true);

err = FEMSol(u_fem.meshes);
err.setData(u_pgd.fullRep() - u_fem.fullRep());

plotSol(err,'xlabel',{'x','k1','k2'},'ylabel','Temperature','title','Error','fixedaxis',true);
plotSol(s_fem,'xlabel',{'x','k1','k2'},'ylabel','Flux','title','FEM Dual Sol.','fixedaxis',true);
plotSol(s_pgd,'xlabel',{'x','k1','k2'},'ylabel','Flux','title','PGD Dual Sol.','fixedaxis',true);

figure('Name','Errors');
    err = e_pgd{end}./norm_e_pgd{end};
    subplot(2,2,1);
        surf(k1.nodes,k2.nodes,squeeze(sum(err,1)));
        xlabel('k1');
        ylabel('k2');
        zlabel('e_{CR}(k1,k2)');
    subplot(2,2,2);
        [~,i] = max(err(:));
        [~,i,j] = ind2sub(size(err),i);
        plotOnElems(x,err(:,i,j));
        xlabel('x');
        ylabel('e_{CR}(x)');
    subplot(2,2,3);
        err_pgd = cellfun(@(e) sqrt(1/2*sum(sum(e(:,i,j),1),2)),e_pgd);
        err_tot = cellfun(@(e) sqrt(1/2*sum(sum(e(:,i,j),1),2)),e_total);
        norm_err = cellfun(@(e) sqrt(1/2*sum(sum(e(:,i,j),1),2)),norm_e_total);
        plot(0:u_pgd.nbModes(),err_pgd./norm_err);
        xlabel('modes');
        ylabel('error');
        legend('Total Error','PGD Error');

i = min(10,u_pgd.nbModes()); % Plot only the first ten modes or less
figure('Name','Modes PGD');
    subplot(5,2,[1 3]);
        plot(x.nodes,u_pgd.data{1}(:,1:i));
        xlabel('x');
        ylabel('\psi');
    h1 = subplot(5,2,[2 4]);
        plot(k1.nodes,u_pgd.data{2}(:,1:i));
        xlabel('k_1');
        ylabel('\gamma_1');
    h2 = subplot(5,2,[5 7]);
        h = plot(k2.nodes,u_pgd.data{3}(:,1:i));
        xlabel('k_2');
        ylabel('\gamma_2');
        gridLegend(h,4,num2str((1:i)','%i-th mode'),'Location','SouthOutside');
        