addpath('../../'); % Add the library

import mesh.*; % Import the mesh library
import fem.*; % Import the fem library
import pgd.*; % Import the pgd library
import error.*; % Import the error library

%% Mesh
% Parameter
L = 1; % Length of the square (space)
dt = 1/10; % Discretization size of time mesh
dk1 = 1/10; % Discretization size of conductivity of the center square
dk2 = 1/10; % Discretization size of parameter of the rest of the mesh

% Create the mesh
x = Mesh(2,'TRI');
ids = x.addNodes([0 0;L 0;L/2 L/4;L/4 L/2;3*L/4 L/2;L/2 3*L/4;0 1;1 1]);
x.addElems([ids(1) ids(2) ids(3);ids(1) ids(3) ids(4);ids(2) ids(5) ids(3); ...
            ids(1) ids(4) ids(7);ids(3) ids(5) ids(4);ids(2) ids(8) ids(5); ...
            ids(4) ids(5) ids(6);ids(7) ids(4) ids(6);ids(5) ids(8) ids(6); ...
            ids(6) ids(8) ids(7)]);

t = segmentMesh(0:dt:1);
k1 = segmentMesh(10.^(0:dk1:1));
k2 = segmentMesh(100*10.^(0:dk1:1));

mesh = cell(4,1);
mesh{1} = x;
mesh{2} = t;
mesh{3} = k1;
mesh{4} = k2;

%% Problem formulation c*du/dt+k*grad(u) + fd = 0
% Parameter
c0 = 0.1; % Specific Heat, constant over the space

% Dirichlet conditions
ud = cell(4,1);
ud{1,1} = @(x) x(2) == 0;
ud{2,1} = @(t) t(1) == 0;
ud{3,1} = @(k1) 0;
ud{4,1} = @(k2) 0;

% Conductivity condition
k = cell(4,2);
k{1,1} = @(x) [1 0;0 1]*(sqrt((x(1) - L/2)^2 + (x(2) - L/2)^2) <= L/4+eps);
k{2,1} = @(t) 1;
k{3,1} = @(k1) k1;
k{4,1} = @(k2) 1;

k{1,2} = @(x) [1 0;0 1]*(sqrt((x(1) - L/2)^2 + (x(2) - L/2)^2) >= L/4+eps);
k{2,2} = @(t) 1;
k{3,2} = @(k1) 1;
k{4,2} = @(k2) k2;

% Specific heat 
c = cell(4,1);
c{1,1} = @(x) c0;
c{2,1} = @(t) 1;
c{3,1} = @(k1) 1;
c{4,1} = @(k2) 1;

% Volumic flux
fd = cell(4,0);

% Linear flux
rd = cell(4,1);
rd{1,1} = @(x) x(2) == L;
rd{2,1} = @(t) 1;
rd{3,1} = @(k1) 1;
rd{4,1} = @(k2) 1;

% Discrete flux
Fd = cell(4,0);

%% Solver
u_fem = femSolver(mesh, c, k, ud, fd, rd, Fd, 0.5);
u_pgd = pgdSolver(mesh, c, k, ud, fd, rd, Fd, 10, 4);

% Error Evaluation
err = rbError(mesh, u_pgd, c, k, ud, fd, rd, Fd);

%% Plot
disp('[-]POST-PROCESSING')
plotFEMSol(mesh,u_fem,'xlabel',{'x','t','k1','k2'},'ylabel','sol','title','plot','fixedaxis',true);

plotPGDSol(mesh,u_pgd,'xlabel',{'x','t','k1','k2'},'ylabel','sol','title','plot','fixedaxis',true);

figure('Name','Modes PGD');
    subplot(2,2,1);
        plotOnNodes(x,u_pgd.data{1}(:,1));
        xlabel('x');
        ylabel('y');
    subplot(2,2,2);
        plot(t.nodes,u_pgd.data{2});
        xlabel('t');
        ylabel('\lambda');
    subplot(2,2,3);
        plot(k1.nodes,u_pgd.data{3});
        xlabel('k_1');
        ylabel('\gamma_1');
    subplot(2,2,4);
        plot(k1.nodes,u_pgd.data{4});
        xlabel('k_2');
        ylabel('\gamma_2');
        
 plotErrSol(mesh,err,'xlabel',{'x','t','k1','k2'},'ylabel','sol','title','plot','fixedaxis',true);

