%% Diez Square problem with 2 materials
%
% A stationnary thermal problem with a different material in the middle
% with a rd = 1 on the top

addpath('../../'); % Add the library

import mesh.*; % Import the mesh library
import fem.*; % Import the fem library
import pgd.*; % Import the pgd library
import error.*; % Import the error library

%% Mesh
% Parameter
L = 1; % Length of the square (space)
dk1 = 1/20; % Discretization size of conductivity of the center square
dk2 = 1/20; % Discretization size of parameter of the rest of the mesh

% Create the mesh
x = Mesh(2,'TRI');
ids = x.addNodes([0 0;L 0;L/2 L/4;L/4 L/2;3*L/4 L/2;L/2 3*L/4;0 1;1 1]);
x.addElems([ids(1) ids(2) ids(3);ids(1) ids(3) ids(4);ids(2) ids(5) ids(3); ...
            ids(1) ids(4) ids(7);ids(3) ids(5) ids(4);ids(2) ids(8) ids(5); ...
            ids(4) ids(5) ids(6);ids(7) ids(4) ids(6);ids(5) ids(8) ids(6); ...
            ids(6) ids(8) ids(7)]);

k1 = segmentMesh(10.^(0:5*dk1:5));
k2 = segmentMesh(0.1*10.^(0:5*dk1:5));

mesh = cell(3,1);
mesh{1} = x;
mesh{2} = k1;
mesh{3} = k2;

%% Problem formulation c*du/dt+k*grad(u) + fd = 0
% Parameter
c0 = 0.1; % Specific Heat, constant over the space

% Dirichlet conditions
ud = cell(3,1);
ud{1,1} = @(x) x(2) == 0;
ud{2,1} = @(k1) 0;
ud{3,1} = @(k2) 0;

% Conductivity condition
k = cell(3,2);
k{1,1} = @(x) [1 0;0 1]*(sqrt((x(1) - L/2)^2 + (x(2) - L/2)^2) <= L/4+eps);
k{2,1} = @(k1) k1;
k{3,1} = @(k2) 1;

k{1,2} = @(x) [1 0;0 1]*(sqrt((x(1) - L/2)^2 + (x(2) - L/2)^2) >= L/4+eps);
k{2,2} = @(k1) 1;
k{3,2} = @(k2) k2;

% Specific heat 
c = cell(3,0);

% Volumic flux
fd = cell(3,0);

% Linear flux
rd = cell(3,1);
rd{1,1} = @(x) 100*[0 x(2) == L]';
rd{2,1} = @(k1) 1;
rd{3,1} = @(k2) 1;

% Discrete flux
Fd = cell(3,0);

%% Solver
u_fem = femSolver(mesh, c, k, ud, fd, rd, Fd, 0.5, true);
u_pgd = pgdSolver(mesh, c, k, ud, fd, rd, Fd, 10, 8, true);

% dual field computation
sigma_fem = femDualField(mesh, u_fem, k);
sigma_pgd = pgdDualField(mesh, u_pgd, c, k, ud, fd, rd, Fd, true);

% Error Evaluation
%err = rbError(mesh, u_pgd, c, k, ud, fd, rd, Fd);

%% Plot
disp('[-]POST-PROCESSING')
plotFEMSol(mesh,u_fem,'xlabel',{'x','k1','k2'},'ylabel','sol','title','FEM Sol','fixedaxis',true);

plotPGDSol(mesh,u_pgd,'xlabel',{'x','k1','k2'},'ylabel','sol','title','PGD Sol','fixedaxis',true);

figure('Name','Modes PGD');
    subplot(2,2,1);
        plotOnNodes(x,u_pgd.data{1});
        xlabel('x');
        ylabel('y');
    subplot(2,2,2);
        plot(k1.nodes,u_pgd.data{2});
        xlabel('k_1');
        ylabel('\gamma_1');
    subplot(2,2,3);
        plot(k2.nodes,u_pgd.data{3});
        xlabel('k_2');
        ylabel('\gamma_2');
        
 %plotErrSol(mesh,err,'xlabel',{'x','t','k1','k2'},'ylabel','sol','title','plot','fixedaxis',true);

