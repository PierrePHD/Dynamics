addpath('../../'); % Add the library

import mesh.*; % Import the mesh library
import fem.*; % Import the fem library
import pgd.*; % Import the pgd library
import error.*; % Import the error library

%% Mesh
% Parameter
L = 1; % Length of the square (space)
dx = L/10; % Discretization size of space mesh
dt = 1/10; % Discretization size of time mesh

mesh = cell(2,1);
mesh{1} = segmentMesh(0:dx:L);
mesh{2} = segmentMesh(0:dt:1);

%% Problem formulation c*du/dt+k*grad(u) + fd = 0
% Dirichlet conditions
ud = cell(2,1);
ud{1,1} = @(x) x(1) == 0;
ud{2,1} = @(t) t(1) == 0;

% Conductivity condition
k = cell(2,1);
k{1,1} = @(x) 1;
k{2,1} = @(t) 1;

% Specific heat 
c = cell(2,1);
c{1,1} = @(x) 0.1;
c{2,1} = @(t) 1;

% Volumic flux
fd = cell(2,0);

% Linear flux
rd = cell(2,1);
rd{1,1} = @(x) x(1) == L;
rd{2,1} = @(t) t(1);

% Discrete flux
Fd = cell(2,0);

%% Solver
u_fem = femSolver(mesh, c, k, ud, fd, rd, Fd, 0.5);
u_pgd = pgdSolver(mesh, c, k, ud, fd, rd, Fd, 10, 4);

%% Plot
disp('[-]POST-PROCESSING')
plotFEMSol(mesh,u_fem,'xlabel',{'x','t'},'ylabel','sol','title','plot','fixedaxis',true);
plotPGDSol(mesh,u_pgd,'xlabel',{'x','t'},'ylabel','sol','title','plot','fixedaxis',true);

figure('Name','Modes PGD');
    subplot(2,2,1);
        plot(mesh{1}.nodes,u_pgd.data{1});
        xlabel('x');
        ylabel('y');
    subplot(2,2,2);
        plot(mesh{2}.nodes,u_pgd.data{2});
        xlabel('t');
        ylabel('\lambda');