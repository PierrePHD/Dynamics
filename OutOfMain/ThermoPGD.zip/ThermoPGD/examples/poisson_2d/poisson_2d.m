%% Poisson Square problem
%
% A d-dimensional space PGD test case of Poisson equation (see Ammar, 
% Chinesta, Diez, Huerta, "An error estimator for separated representation 
% of highly multidimensional models" 2010) for algorithm tes purpose.
%
% The problem is: 
%           -\nabla u = \sum_{i=1}^m \prod_{j=1}^d sin(i*pi*x_j)
%
% The exact solution is known:
%           u = \sum_{i=1}^m \prod_{j=1}^d (1/(2*i*pi)*sin(i*pi*x_j))
%

addpath('../../'); % Add the library

import mesh.*; % Import the mesh library
import fem.*; % Import the fem library
import pgd.*; % Import the pgd library
import utils.*; % Usefull functions

%% Parameter of the case
L = 1; % Length of the beam
nx = 20; % Number of elements in space
d = 3; % Number of spatials dimensions
m = 20; % Number of modes

%% Mesh
x = cell(d,1);
for i=1:d
    x{i} = segmentMesh(0:L/nx:L);
end

%% Problem formulation 
fd = cell(d,m);
for i=1:m
    for j=1:d
        fd{j,i} = @(x) sin(i*pi*x);
    end
end

ud = cell(d,1);
for j=1:d
    ud{j,1} = @(x) x == 0 || x == L;
end

%% Solution computation
u_pgd = poissonPgdSolver(x, ud, fd, m, 4);

%% Post-processing
disp('[-]POST-PROCESSING')

n = min(6,d); % Plot only the frist 6 dimension or less
i = min(10,u_pgd.nbModes()); % Plot only the first ten modes or less

figure('Name','Modes PGD');
for j=1:n
    q = floor(j/4);
    subplot(2*ceil(n/3)+1,3,3*q+(j:3:j+3));
    h = plot(x{j}.nodes,u_pgd.data{j}(:,1:i));
    xlabel(['x_' num2str(j)]);
    ylabel(['\psi_' num2str(j)]);
end
subplot(2*ceil(n/3)+1,3,6*ceil(n/3)+(1:3));
axis off;
gridLegend(h,4,num2str((1:i)','%i-th mode'));        
        